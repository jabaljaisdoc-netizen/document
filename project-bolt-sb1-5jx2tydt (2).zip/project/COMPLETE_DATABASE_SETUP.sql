/*
  ============================================================================
  FLUXFILE DOCUMENT MANAGEMENT SYSTEM - COMPLETE DATABASE SETUP
  ============================================================================

  This is a complete SQL script to set up the entire FluxFile Document
  Management System on a fresh Supabase instance.

  INSTRUCTIONS FOR USE:
  1. Create a new Supabase project at https://supabase.com/dashboard
  2. Go to SQL Editor in your Supabase dashboard
  3. Copy and paste this ENTIRE file
  4. Click "Run" to execute all commands
  5. Create your first admin user (see bottom of this file)

  FEATURES INCLUDED:
  - Client and document management
  - Staff profiles with admin/staff roles
  - Comprehensive security with Row Level Security (RLS)
  - Document storage with file upload support
  - Expiry tracking and notifications
  - Cancelled document management
  - Phone number search optimization
  - Complete audit trail

  ============================================================================
*/

-- ============================================================================
-- STEP 1: CREATE TABLES
-- ============================================================================

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  document_name text NOT NULL,
  document_number text,
  file_url text,
  file_name text,
  expiry_date date NOT NULL,
  issue_date date,
  notes text DEFAULT '',
  status text DEFAULT 'valid',
  uploaded_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  client_phone text DEFAULT '',
  doc_type text DEFAULT 'Other',
  reminder_setting text DEFAULT '1 Week Before',
  notification_date date,
  email_sent boolean DEFAULT false,
  uploaded_by_name text DEFAULT '',
  client_name text DEFAULT ''
);

-- Add comment for documents table
COMMENT ON TABLE documents IS 'Indexes optimized for:
- Foreign key relationships (client_id, uploaded_by)
- Expiry date filtering and sorting
- Notification date queries for email triggers
- Status-based filtering
- Role-based access control queries';

-- Create staff profiles table
CREATE TABLE IF NOT EXISTS staff_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text DEFAULT 'staff' CHECK (role IN ('admin', 'staff')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Add comment for staff profiles table
COMMENT ON TABLE staff_profiles IS 'RLS Policies:
- Users can view/update their own profile
- Admins can view/update/delete all staff profiles
- Only active admins have management privileges';

-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
  id text PRIMARY KEY DEFAULT 'global',
  admin_email text DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

-- Insert default settings
INSERT INTO settings (id, admin_email, updated_at)
VALUES ('global', '', now())
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- STEP 2: ENABLE ROW LEVEL SECURITY (RLS)
-- ============================================================================

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- STEP 3: CREATE STORAGE BUCKET FOR DOCUMENTS
-- ============================================================================

INSERT INTO storage.buckets (id, name, public)
VALUES ('documents', 'documents', false)
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- STEP 4: CREATE INDEXES FOR PERFORMANCE
-- ============================================================================

-- Documents table indexes
CREATE INDEX IF NOT EXISTS idx_documents_expiry_date ON documents(expiry_date);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);

-- ============================================================================
-- STEP 5: CREATE RLS POLICIES FOR CLIENTS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Authenticated staff can view all clients" ON clients;
CREATE POLICY "Authenticated staff can view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated staff can insert clients" ON clients;
CREATE POLICY "Authenticated staff can insert clients"
  ON clients FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated staff can update clients" ON clients;
CREATE POLICY "Authenticated staff can update clients"
  ON clients FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated staff can delete clients" ON clients;
CREATE POLICY "Authenticated staff can delete clients"
  ON clients FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

-- ============================================================================
-- STEP 6: CREATE RLS POLICIES FOR DOCUMENTS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Authenticated users can view all documents" ON documents;
CREATE POLICY "Authenticated users can view all documents"
  ON documents FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated users can insert documents" ON documents;
CREATE POLICY "Authenticated users can insert documents"
  ON documents FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated users can update documents" ON documents;
CREATE POLICY "Authenticated users can update documents"
  ON documents FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated users can delete documents" ON documents;
CREATE POLICY "Authenticated users can delete documents"
  ON documents FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.is_active = true
    )
  );

-- ============================================================================
-- STEP 7: CREATE RLS POLICIES FOR STAFF PROFILES TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Authenticated users can view all staff" ON staff_profiles;
CREATE POLICY "Authenticated users can view all staff"
  ON staff_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.is_active = true
    )
  );

DROP POLICY IF EXISTS "Admins can insert staff profiles" ON staff_profiles;
CREATE POLICY "Admins can insert staff profiles"
  ON staff_profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated users can update staff profiles" ON staff_profiles;
CREATE POLICY "Authenticated users can update staff profiles"
  ON staff_profiles FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id
    OR EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  )
  WITH CHECK (
    auth.uid() = id
    OR EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  );

DROP POLICY IF EXISTS "Admins can delete staff" ON staff_profiles;
CREATE POLICY "Admins can delete staff"
  ON staff_profiles FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = auth.uid()
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  );

-- ============================================================================
-- STEP 8: CREATE RLS POLICIES FOR SETTINGS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Authenticated staff can view settings" ON settings;
CREATE POLICY "Authenticated staff can view settings"
  ON settings FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

DROP POLICY IF EXISTS "Admins can update settings" ON settings;
CREATE POLICY "Admins can update settings"
  ON settings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.role = 'admin'
      AND staff_profiles.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.role = 'admin'
      AND staff_profiles.is_active = true
    )
  );

-- ============================================================================
-- STEP 9: CREATE STORAGE POLICIES FOR DOCUMENTS BUCKET
-- ============================================================================

DROP POLICY IF EXISTS "Authenticated staff can upload documents" ON storage.objects;
CREATE POLICY "Authenticated staff can upload documents"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated staff can view stored documents" ON storage.objects;
CREATE POLICY "Authenticated staff can view stored documents"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

DROP POLICY IF EXISTS "Authenticated staff can delete stored documents" ON storage.objects;
CREATE POLICY "Authenticated staff can delete stored documents"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

-- ============================================================================
-- STEP 10: CREATE HELPER FUNCTIONS
-- ============================================================================

-- Function to automatically update status based on expiry date
CREATE OR REPLACE FUNCTION update_document_status()
RETURNS trigger AS $$
BEGIN
  IF NEW.expiry_date < CURRENT_DATE THEN
    NEW.status = 'expired';
  ELSIF NEW.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN
    NEW.status = 'expiring_soon';
  ELSE
    NEW.status = 'valid';
  END IF;

  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- STEP 11: CREATE TRIGGERS
-- ============================================================================

-- Trigger to update document status on insert/update
DROP TRIGGER IF EXISTS trigger_update_document_status ON documents;
CREATE TRIGGER trigger_update_document_status
  BEFORE INSERT OR UPDATE OF expiry_date ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_document_status();

-- Trigger to update clients updated_at
DROP TRIGGER IF EXISTS update_clients_updated_at ON clients;
CREATE TRIGGER update_clients_updated_at
  BEFORE UPDATE ON clients
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger to update documents updated_at
DROP TRIGGER IF EXISTS update_documents_updated_at ON documents;
CREATE TRIGGER update_documents_updated_at
  BEFORE UPDATE ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- SETUP COMPLETE!
-- ============================================================================

/*
  ============================================================================
  NEXT STEPS: CREATE YOUR FIRST ADMIN USER
  ============================================================================

  OPTION 1: Using Supabase Dashboard (RECOMMENDED)
  ------------------------------------------------
  1. Go to Authentication > Users in your Supabase dashboard
  2. Click "Add user"
  3. Choose "Create new user"
  4. Enter email and password
  5. Click "Create user"
  6. Copy the user ID from the users table
  7. Run this SQL command (replace YOUR_USER_ID with the actual ID):

     INSERT INTO staff_profiles (id, full_name, role, is_active)
     VALUES ('YOUR_USER_ID', 'Admin User', 'admin', true);


  OPTION 2: Using SQL (Advanced)
  --------------------------------
  Note: This requires the service_role key which should NEVER be exposed
  in client code. Only use this in the SQL Editor.

  -- First, create the auth user (you'll need to provide your own password)
  -- This is NOT recommended as it's less secure. Use Option 1 instead.


  ============================================================================
  ENVIRONMENT VARIABLES FOR YOUR APPLICATION
  ============================================================================

  Create a .env file in your project root with these values:
  (Get these from your Supabase project settings > API)

  VITE_SUPABASE_URL=https://your-project-ref.supabase.co
  VITE_SUPABASE_ANON_KEY=your-anon-key-here

  ============================================================================
  VERIFICATION QUERIES
  ============================================================================

  -- Check if tables were created successfully
  SELECT table_name
  FROM information_schema.tables
  WHERE table_schema = 'public'
  ORDER BY table_name;

  -- Verify RLS is enabled
  SELECT tablename, rowsecurity
  FROM pg_tables
  WHERE schemaname = 'public';

  -- Check storage bucket
  SELECT * FROM storage.buckets WHERE id = 'documents';

  -- View all staff profiles
  SELECT id, full_name, role, is_active, created_at
  FROM staff_profiles
  ORDER BY created_at DESC;

  ============================================================================
  SUPPORT & DOCUMENTATION
  ============================================================================

  For more information about FluxFile Document Management System:
  - Check the README.md file in your project
  - Visit Supabase documentation: https://supabase.com/docs

  ============================================================================
*/
