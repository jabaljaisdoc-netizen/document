# Security Configuration Guide

## ⚠️ MANUAL ACTION REQUIRED: Leaked Password Protection

Supabase Auth can prevent the use of compromised passwords by checking against the HaveIBeenPwned.org database. **This feature MUST be enabled manually through the Supabase Dashboard.**

### How to Enable (REQUIRED):

1. Go to your Supabase Dashboard
2. Navigate to **Authentication** → **Providers** → **Email**
3. Scroll down to the **Security** section
4. Find **"Enable breach password protection"** or **"Enable HaveIBeenPwned password protection"**
5. **Toggle it ON**
6. Click **Save**

**Why This Matters:**
- Prevents users from using passwords that have been compromised in data breaches
- Automatically checks against 600+ million compromised passwords
- Improves overall account security
- Protects against credential stuffing attacks

This will automatically check all new password registrations and password changes against the HaveIBeenPwned database to ensure users are not using compromised passwords.

## Completed Security Fixes

The following security and performance issues have been automatically resolved:

### ✅ RLS Performance Optimizations
- All `auth.uid()` calls wrapped with `(select auth.uid())` to prevent re-evaluation per row
- Significantly improves query performance at scale
- Affects policies on: `staff_profiles`, `settings`, `documents`

### ✅ Multiple Permissive Policies Fixed
- Consolidated multiple SELECT policies on `documents` table into a single policy
- Prevents policy conflicts and improves performance
- New policy: "Authenticated users can view documents"

### ✅ Function Search Path Security
- Added `SET search_path = public, pg_temp` to all functions
- Added `STABLE` and `SECURITY DEFINER` attributes
- Functions secured: `is_active_staff()`, `update_document_status()`, `update_updated_at_column()`

### ✅ Foreign Key Index Optimization
- Added indexes for all foreign key columns (`client_id`, `uploaded_by`)
- Significantly improves JOIN performance and referential integrity checks
- Prevents query performance degradation at scale

### ✅ Query Pattern Optimization
- Created targeted indexes based on actual application query patterns
- Indexes for: expiry_date filtering, notification_date checks, status filtering
- Removed unused composite indexes
- Optimized for both admin (all documents) and staff (own documents) queries

## Current Security Status

- ✅ Row Level Security (RLS) enabled on all tables
- ✅ Optimized RLS policies for performance (auth functions with SELECT)
- ✅ Secure function definitions with proper search paths
- ✅ All foreign keys properly indexed
- ✅ Query-optimized indexes for application patterns
- ✅ No unused indexes consuming resources
- ⚠️ **Manual Action Required**: Enable leaked password protection in Dashboard (see above)

## Best Practices Applied

1. **Principle of Least Privilege**: Users can only access their own data unless they're admins
2. **Defense in Depth**: Multiple layers of security (RLS + application logic)
3. **Performance Optimization**:
   - Optimized policies don't re-evaluate auth functions
   - All foreign keys indexed for fast JOINs
   - Targeted indexes for common query patterns
4. **Audit Trail**: `uploaded_by` and timestamps track all changes
5. **Data Integrity**: Foreign key constraints and CHECK constraints enforce data quality
6. **Index Strategy**: Only maintain indexes that are actively used by queries

## Database Performance Metrics

### Indexes Created:
- `idx_documents_client_id` - Foreign key index for client relationships
- `idx_documents_uploaded_by` - Foreign key index for staff relationships
- `idx_documents_expiry_date` - For expiry filtering and sorting
- `idx_documents_notification_date` - For email notification queries (partial index)
- `idx_documents_status_expiry` - Composite for status-based queries
- `idx_staff_profiles_active` - For active staff lookups (partial index)
- `idx_staff_profiles_role` - For role-based access control

### Performance Benefits:
- Fast foreign key integrity checks
- Optimized JOIN operations between documents and staff_profiles
- Quick filtering on expiry dates (most common query)
- Efficient notification date lookups for email triggers
- Role-based queries execute instantly
