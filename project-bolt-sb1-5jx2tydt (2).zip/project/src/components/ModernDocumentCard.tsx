import { FileText, Calendar, Download, Trash2, MessageCircle, Edit, Phone } from 'lucide-react';
import { Document } from '../lib/supabase';
import { differenceInDays, format } from 'date-fns';

interface ModernDocumentCardProps {
  document: Document;
  onDelete: (id: string) => void;
  onDownload: (fileUrl: string, fileName: string) => void;
  onEdit: (document: Document) => void;
}

export default function ModernDocumentCard({ document, onDelete, onDownload, onEdit }: ModernDocumentCardProps) {
  const today = new Date();
  const expiryDate = new Date(document.expiry_date);
  const daysUntilExpiry = differenceInDays(expiryDate, today);

  const getTrafficLightStatus = () => {
    if (daysUntilExpiry < 0) {
      return {
        color: 'bg-red-500',
        label: 'EXPIRED',
        bgGradient: 'from-red-50 to-red-100',
        borderColor: 'border-red-300',
        textColor: 'text-red-700',
      };
    } else if (daysUntilExpiry < 7) {
      return {
        color: 'bg-red-500',
        label: 'URGENT',
        bgGradient: 'from-red-50 to-red-100',
        borderColor: 'border-red-300',
        textColor: 'text-red-700',
      };
    } else if (daysUntilExpiry < 30) {
      return {
        color: 'bg-amber-500',
        label: 'WARNING',
        bgGradient: 'from-amber-50 to-amber-100',
        borderColor: 'border-amber-300',
        textColor: 'text-amber-700',
      };
    } else {
      return {
        color: 'bg-green-500',
        label: 'SAFE',
        bgGradient: 'from-green-50 to-green-100',
        borderColor: 'border-green-300',
        textColor: 'text-green-700',
      };
    }
  };

  const status = getTrafficLightStatus();

  const handleWhatsApp = () => {
    const phone = document.client_phone || '';
    const clientName = document.client_name || 'Client';
    const docType = document.doc_type || 'document';
    const expiry = format(expiryDate, 'MMMM dd, yyyy');

    const message = `Hello ${clientName}, your ${docType} expires on ${expiry}.`;
    const url = phone
      ? `https://wa.me/${phone.replace(/[^\d]/g, '')}?text=${encodeURIComponent(message)}`
      : 'https://wa.me/';

    window.open(url, '_blank');
  };

  const getDaysText = () => {
    if (daysUntilExpiry < 0) return `Expired ${Math.abs(daysUntilExpiry)} days ago`;
    if (daysUntilExpiry === 0) return 'Expires TODAY';
    if (daysUntilExpiry === 1) return 'Expires TOMORROW';
    return `${daysUntilExpiry} days remaining`;
  };

  return (
    <div className={`bg-gradient-to-br ${status.bgGradient} rounded-2xl border-2 ${status.borderColor} shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden`}>
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="p-3 bg-white rounded-xl shadow-sm">
            <FileText className={`h-8 w-8 ${status.textColor}`} />
          </div>

          <div className={`px-4 py-2 ${status.color} text-white rounded-full font-bold text-xs tracking-wider shadow-lg`}>
            {status.label}
          </div>
        </div>

        <div className="mb-4">
          <h3 className="text-lg font-bold text-slate-900 mb-1">
            {document.client_name || 'Unknown Client'}
          </h3>
          <p className="text-sm font-medium text-slate-700">
            {document.doc_type || 'Document Type'}
          </p>
        </div>

        <div className="space-y-2 mb-4">
          {document.client_phone && (
            <div className="flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-slate-500" />
              <span className="text-slate-700 font-medium">
                {document.client_phone}
              </span>
            </div>
          )}
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="h-4 w-4 text-slate-500" />
            <span className="text-slate-700">
              <span className="font-semibold">Expiry:</span> {format(expiryDate, 'MMM dd, yyyy')}
            </span>
          </div>
          <div className={`text-sm font-bold ${status.textColor}`}>
            {getDaysText()}
          </div>
          {document.uploaded_by_name && (
            <div className="text-xs text-slate-500">
              Uploaded by {document.uploaded_by_name}
            </div>
          )}
        </div>

        {document.notes && (
          <div className="mb-4 p-3 bg-white/60 rounded-lg border border-slate-200">
            <p className="text-xs text-slate-600">{document.notes}</p>
          </div>
        )}

        <div className="flex gap-2">
          <button
            onClick={handleWhatsApp}
            className="flex items-center justify-center px-3 py-2.5 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors shadow-md hover:shadow-lg"
            title="Send WhatsApp message"
          >
            <MessageCircle className="h-4 w-4" />
          </button>

          <button
            onClick={() => onEdit(document)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors shadow-md"
          >
            <Edit className="h-4 w-4" />
            Edit
          </button>

          {document.file_url && document.file_name && (
            <button
              onClick={() => onDownload(document.file_url!, document.file_name!)}
              className="flex items-center justify-center px-3 py-2.5 bg-white text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-colors shadow-md"
              title="Download document"
            >
              <Download className="h-4 w-4" />
            </button>
          )}

          <button
            onClick={() => onDelete(document.id)}
            className="flex items-center justify-center px-3 py-2.5 bg-white text-red-600 rounded-xl font-semibold hover:bg-red-50 transition-colors shadow-md"
            title="Delete document"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
