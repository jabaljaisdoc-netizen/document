import { FileText, Calendar, AlertCircle, CheckCircle, Download, Trash2 } from 'lucide-react';
import { Document } from '../lib/supabase';

interface DocumentCardProps {
  document: Document;
  onDelete: (id: string) => void;
  onDownload: (fileUrl: string, fileName: string) => void;
}

export default function DocumentCard({ document, onDelete, onDownload }: DocumentCardProps) {
  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'expired':
        return {
          color: 'bg-red-100 border-red-300',
          textColor: 'text-red-800',
          icon: AlertCircle,
          iconColor: 'text-red-600',
          label: 'Expired'
        };
      case 'expiring_soon':
        return {
          color: 'bg-amber-100 border-amber-300',
          textColor: 'text-amber-800',
          icon: AlertCircle,
          iconColor: 'text-amber-600',
          label: 'Expiring Soon'
        };
      default:
        return {
          color: 'bg-green-100 border-green-300',
          textColor: 'text-green-800',
          icon: CheckCircle,
          iconColor: 'text-green-600',
          label: 'Valid'
        };
    }
  };

  const statusConfig = getStatusConfig(document.status);
  const StatusIcon = statusConfig.icon;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getDaysUntilExpiry = () => {
    const today = new Date();
    const expiry = new Date(document.expiry_date);
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return `Expired ${Math.abs(diffDays)} days ago`;
    if (diffDays === 0) return 'Expires today';
    if (diffDays === 1) return 'Expires tomorrow';
    return `Expires in ${diffDays} days`;
  };

  return (
    <div className={`border-2 rounded-xl p-5 transition-all hover:shadow-lg ${statusConfig.color}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-lg ${statusConfig.color}`}>
            <FileText className={`h-6 w-6 ${statusConfig.iconColor}`} />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 text-lg">{document.document_name}</h3>
            {document.clients && (
              <p className="text-sm text-slate-600 mt-1">{document.clients.name}</p>
            )}
          </div>
        </div>

        <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full ${statusConfig.color}`}>
          <StatusIcon className={`h-4 w-4 ${statusConfig.iconColor}`} />
          <span className={`text-xs font-medium ${statusConfig.textColor}`}>
            {statusConfig.label}
          </span>
        </div>
      </div>

      {document.document_number && (
        <div className="mb-3">
          <p className="text-sm text-slate-600">
            <span className="font-medium">Document #:</span> {document.document_number}
          </p>
        </div>
      )}

      <div className="space-y-2 mb-4">
        <div className="flex items-center gap-2 text-sm">
          <Calendar className="h-4 w-4 text-slate-500" />
          <span className="text-slate-700">
            <span className="font-medium">Expires:</span> {formatDate(document.expiry_date)}
          </span>
        </div>
        <div className={`text-sm font-medium ${statusConfig.textColor}`}>
          {getDaysUntilExpiry()}
        </div>
      </div>

      {document.notes && (
        <div className="mb-4 p-3 bg-white bg-opacity-50 rounded-lg">
          <p className="text-sm text-slate-700">{document.notes}</p>
        </div>
      )}

      <div className="flex gap-2 pt-3 border-t border-slate-200">
        {document.file_url && document.file_name && (
          <button
            onClick={() => onDownload(document.file_url!, document.file_name!)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-white text-blue-600 rounded-lg font-medium hover:bg-blue-50 transition-colors text-sm"
          >
            <Download className="h-4 w-4" />
            Download
          </button>
        )}
        <button
          onClick={() => onDelete(document.id)}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-white text-red-600 rounded-lg font-medium hover:bg-red-50 transition-colors text-sm"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
