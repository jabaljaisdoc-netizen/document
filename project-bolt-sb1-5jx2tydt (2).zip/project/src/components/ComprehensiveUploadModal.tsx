import { useState } from 'react';
import { X, Upload, FileText } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { subDays, subWeeks, subMonths, format } from 'date-fns';

interface ComprehensiveUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function ComprehensiveUploadModal({
  isOpen,
  onClose,
  onSuccess,
}: ComprehensiveUploadModalProps) {
  const { user, profile } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [docType, setDocType] = useState('Visa');
  const [otherDocType, setOtherDocType] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [reminderSetting, setReminderSetting] = useState('1 Week Before');
  const [customDate, setCustomDate] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const docTypes = ['Visa', 'License', 'Insurance', 'Passport', 'Other'];
  const reminderOptions = ['1 Week Before', '2 Weeks Before', '1 Month Before', 'Custom Date'];

  const calculateNotificationDate = (): string | null => {
    if (!expiryDate) return null;

    const expiry = new Date(expiryDate);

    switch (reminderSetting) {
      case '1 Week Before':
        return format(subWeeks(expiry, 1), 'yyyy-MM-dd');
      case '2 Weeks Before':
        return format(subWeeks(expiry, 2), 'yyyy-MM-dd');
      case '1 Month Before':
        return format(subMonths(expiry, 1), 'yyyy-MM-dd');
      case 'Custom Date':
        return customDate || null;
      default:
        return null;
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!clientName || !expiryDate) {
        throw new Error('Please fill in all required fields');
      }

      const finalDocType = docType === 'Other' ? otherDocType : docType;

      if (docType === 'Other' && !otherDocType.trim()) {
        throw new Error('Please specify the document type');
      }

      const notificationDate = calculateNotificationDate();

      let fileUrl = null;
      let fileName = null;

      if (file) {
        const fileExt = file.name.split('.').pop();
        const filePath = `${user?.id}/${Date.now()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('documents')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        fileUrl = filePath;
        fileName = file.name;
      }

      const cleanedPhone = clientPhone.replace(/\s+/g, '');

      const { error: docError } = await supabase.from('documents').insert({
        client_name: clientName,
        client_phone: cleanedPhone,
        doc_type: finalDocType,
        document_name: finalDocType,
        expiry_date: expiryDate,
        reminder_setting: reminderSetting,
        notification_date: notificationDate,
        notes: notes,
        file_url: fileUrl,
        file_name: fileName,
        uploaded_by: user?.id,
        uploaded_by_name: profile?.full_name || '',
        email_sent: false,
      });

      if (docError) throw docError;

      onSuccess();
      resetForm();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload document');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setClientName('');
    setClientPhone('');
    setDocType('Visa');
    setOtherDocType('');
    setExpiryDate('');
    setReminderSetting('1 Week Before');
    setCustomDate('');
    setNotes('');
    setError('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-5 flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <Upload className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">New Upload</h2>
          </div>
          <button onClick={handleClose} className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded">
              <p className="font-medium">Error</p>
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
              dragActive
                ? 'border-blue-500 bg-blue-50'
                : 'border-slate-300 hover:border-blue-400 hover:bg-slate-50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <input
              type="file"
              onChange={handleFileChange}
              className="hidden"
              id="file-upload"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
            />
            <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center">
              {file ? (
                <>
                  <FileText className="h-12 w-12 text-blue-600 mb-3" />
                  <p className="text-sm font-semibold text-slate-900">{file.name}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </>
              ) : (
                <>
                  <Upload className="h-12 w-12 text-slate-400 mb-3" />
                  <p className="text-base font-semibold text-slate-700 mb-1">
                    Drag & drop your file here
                  </p>
                  <p className="text-sm text-slate-500 mb-2">or click to browse</p>
                  <p className="text-xs text-slate-400">PDF, DOC, DOCX, JPG, PNG (Max 10MB)</p>
                </>
              )}
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Client Name *
              </label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                required
                placeholder="Enter client name"
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Client Phone *
              </label>
              <input
                type="tel"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                required
                placeholder="+971 50 123 4567"
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              />
              <p className="text-xs text-slate-500 mt-1">Required for WhatsApp integration</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Document Type *
              </label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              >
                {docTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>

              {docType === 'Other' && (
                <input
                  type="text"
                  value={otherDocType}
                  onChange={(e) => setOtherDocType(e.target.value)}
                  required={docType === 'Other'}
                  placeholder="Specify document type"
                  className="mt-3 w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                />
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Expiry Date *
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Reminder Trigger *
            </label>
            <select
              value={reminderSetting}
              onChange={(e) => setReminderSetting(e.target.value)}
              required
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            >
              {reminderOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>

            {reminderSetting === 'Custom Date' && (
              <div className="mt-3">
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Notification Date *
                </label>
                <input
                  type="date"
                  value={customDate}
                  onChange={(e) => setCustomDate(e.target.value)}
                  required={reminderSetting === 'Custom Date'}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                />
              </div>
            )}

            {expiryDate && reminderSetting !== 'Custom Date' && (
              <p className="text-sm text-slate-600 mt-2">
                Notification will be sent on:{' '}
                <span className="font-semibold">
                  {calculateNotificationDate()
                    ? format(new Date(calculateNotificationDate()!), 'MMM dd, yyyy')
                    : 'N/A'}
                </span>
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="Add any additional notes or comments"
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
            />
          </div>

          <div className="flex gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 px-6 py-3 border-2 border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
            >
              {loading ? 'Uploading...' : 'Upload Document'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
