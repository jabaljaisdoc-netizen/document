import { useState, useEffect } from 'react';
import { Mail, Save, Check } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface SettingsPageProps {
  onToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

export default function SettingsPage({ onToast }: SettingsPageProps) {
  const [adminEmail, setAdminEmail] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('settings')
      .select('admin_email')
      .eq('id', 'global')
      .maybeSingle();

    if (error) {
      console.error('Error loading settings:', error);
      onToast('Failed to load settings', 'error');
    } else {
      setAdminEmail(data?.admin_email || '');
    }
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const { error } = await supabase
      .from('settings')
      .update({ admin_email: adminEmail })
      .eq('id', 'global');

    if (error) {
      console.error('Error saving settings:', error);
      onToast('Failed to save settings', 'error');
    } else {
      onToast('Settings saved successfully', 'success');
    }

    setSaving(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl">
      <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-jdc-50 rounded-xl">
            <Mail className="h-6 w-6 text-jdc-900" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Notification Settings</h2>
            <p className="text-sm text-slate-600">Configure email notifications for document expiry</p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Admin Notification Email
            </label>
            <input
              type="email"
              value={adminEmail}
              onChange={(e) => setAdminEmail(e.target.value)}
              placeholder="admin@company.com"
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
            <p className="text-sm text-slate-500 mt-2">
              This email will receive notifications when documents enter warning or critical status
            </p>
          </div>

          <div className="bg-jdc-50 border border-jdc-200 rounded-xl p-4">
            <p className="text-sm text-jdc-900">
              <span className="font-semibold">Note:</span> Email notifications are currently simulated
              and will appear as toast messages in the app. Integration with a real email service can
              be configured in production.
            </p>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-200">
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-jdc-900 to-jdc-800 text-white rounded-xl font-semibold hover:from-jdc-800 hover:to-jdc-950 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
            >
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Save Settings
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
