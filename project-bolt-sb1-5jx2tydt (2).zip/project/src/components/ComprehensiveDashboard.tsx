import { useState, useEffect } from 'react';
import { Search, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Document } from '../lib/supabase';
import { differenceInDays, isPast } from 'date-fns';
import Sidebar from './Sidebar';
import StatsBar from './StatsBar';
import NotificationBell from './NotificationBell';
import ModernDocumentCard from './ModernDocumentCard';
import ComprehensiveUploadModal from './ComprehensiveUploadModal';
import EditDocumentModal from './EditDocumentModal';
import StaffManagementModal from './StaffManagementModal';
import SettingsPage from './SettingsPage';
import ProfilePage from './ProfilePage';
import ToastContainer from './ToastContainer';

export default function ComprehensiveDashboard() {
  const { profile, user } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [documents, setDocuments] = useState<Document[]>([]);
  const [filteredDocuments, setFilteredDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingDocument, setEditingDocument] = useState<Document | null>(null);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [quickFilter, setQuickFilter] = useState<string>('all');
  const [toasts, setToasts] = useState<Array<{ id: string; message: string; type: 'success' | 'error' | 'info' }>>([]);
  const [emailChecked, setEmailChecked] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadDocuments();
  }, []);

  useEffect(() => {
    filterDocuments();
  }, [documents, searchQuery, quickFilter, activeTab]);

  useEffect(() => {
    checkForEmailNotifications();
  }, [documents, emailChecked]);

  const loadDocuments = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .order('expiry_date', { ascending: true });

    if (error) {
      console.error('Error loading documents:', error);
      showToast('Failed to load documents', 'error');
    } else {
      setDocuments(data || []);
    }
    setLoading(false);
  };

  const checkForEmailNotifications = async () => {
    const today = new Date();

    for (const doc of documents) {
      if (emailChecked.has(doc.id)) continue;
      if (doc.email_sent) continue;

      const daysUntilExpiry = differenceInDays(new Date(doc.expiry_date), today);
      const isWarning = daysUntilExpiry < 30 && daysUntilExpiry >= 0;

      if (isWarning && doc.notification_date && isPast(new Date(doc.notification_date))) {
        const { data: settings } = await supabase
          .from('settings')
          .select('admin_email')
          .eq('id', 'global')
          .maybeSingle();

        const adminEmail = settings?.admin_email || 'admin@company.com';

        showToast(
          `Simulating email to ${adminEmail} for ${doc.client_name || 'client'} - ${doc.doc_type} expiring soon`,
          'info'
        );

        await supabase
          .from('documents')
          .update({ email_sent: true })
          .eq('id', doc.id);

        setEmailChecked(prev => new Set(prev).add(doc.id));
      }
    }
  };

  const filterDocuments = () => {
    let filtered = documents;

    if (activeTab === 'uploads') {
      filtered = filtered.filter((doc) => doc.uploaded_by === user?.id);
    }

    if (quickFilter === 'expiring_week') {
      const today = new Date();
      filtered = filtered.filter((doc) => {
        const days = differenceInDays(new Date(doc.expiry_date), today);
        return days >= 0 && days < 7 && doc.status !== 'cancelled';
      });
    } else if (quickFilter === 'expired') {
      filtered = filtered.filter((doc) => {
        return differenceInDays(new Date(doc.expiry_date), new Date()) < 0 && doc.status !== 'cancelled';
      });
    } else if (quickFilter === 'cancelled') {
      filtered = filtered.filter((doc) => doc.status === 'cancelled');
    } else if (quickFilter === 'all') {
      filtered = filtered.filter((doc) => doc.status !== 'cancelled');
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (doc) =>
          doc.client_name?.toLowerCase().includes(query) ||
          doc.doc_type?.toLowerCase().includes(query) ||
          doc.document_name?.toLowerCase().includes(query) ||
          doc.client_phone?.toLowerCase().includes(query)
      );
    }

    setFilteredDocuments(filtered);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this document?')) return;

    const doc = documents.find((d) => d.id === id);
    if (doc?.file_url) {
      await supabase.storage.from('documents').remove([doc.file_url]);
    }

    const { error } = await supabase.from('documents').delete().eq('id', id);

    if (error) {
      console.error('Error deleting document:', error);
      showToast('Failed to delete document', 'error');
    } else {
      showToast('Document deleted successfully', 'success');
      loadDocuments();
    }
  };

  const handleDownload = async (fileUrl: string, fileName: string) => {
    const { data, error } = await supabase.storage.from('documents').download(fileUrl);

    if (error) {
      console.error('Error downloading file:', error);
      showToast('Failed to download file', 'error');
      return;
    }

    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleEdit = (document: Document) => {
    setEditingDocument(document);
    setShowEditModal(true);
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, message, type }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
      case 'uploads':
        return (
          <>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-slate-900">
                  {activeTab === 'dashboard' ? 'Dashboard' : 'My Uploads'}
                </h1>
                <p className="text-slate-600 mt-1">
                  {activeTab === 'dashboard'
                    ? 'Monitor document expiry status'
                    : 'View and manage your uploaded documents'}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <NotificationBell documents={documents} />
                <button
                  onClick={() => setShowUploadModal(true)}
                  className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl"
                >
                  <Plus className="h-5 w-5" />
                  New Upload
                </button>
              </div>
            </div>

            <StatsBar documents={documents} />

            <div className="mb-6 space-y-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by client name, document type, or phone number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none shadow-sm"
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setQuickFilter('all')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    quickFilter === 'all'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  All Documents
                </button>
                <button
                  onClick={() => setQuickFilter('expiring_week')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    quickFilter === 'expiring_week'
                      ? 'bg-amber-600 text-white shadow-md'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  Expiring This Week
                </button>
                <button
                  onClick={() => setQuickFilter('expired')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    quickFilter === 'expired'
                      ? 'bg-red-600 text-white shadow-md'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  Expired
                </button>
                <button
                  onClick={() => setQuickFilter('cancelled')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    quickFilter === 'cancelled'
                      ? 'bg-gray-600 text-white shadow-md'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  Cancelled
                </button>
              </div>
            </div>

            {loading ? (
              <div className="text-center py-20">
                <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600"></div>
                <p className="mt-4 text-slate-600 font-medium">Loading documents...</p>
              </div>
            ) : filteredDocuments.length === 0 ? (
              <div className="text-center py-20 bg-white rounded-2xl border border-slate-200">
                <div className="text-6xl mb-4">📄</div>
                <h3 className="text-xl font-semibold text-slate-700 mb-2">No documents found</h3>
                <p className="text-slate-500 mb-6">
                  {searchQuery || quickFilter !== 'all'
                    ? 'Try adjusting your filters or search query'
                    : 'Upload your first document to get started'}
                </p>
                {!searchQuery && quickFilter === 'all' && (
                  <button
                    onClick={() => setShowUploadModal(true)}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors"
                  >
                    <Plus className="h-5 w-5" />
                    Upload Document
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredDocuments.map((document) => (
                  <ModernDocumentCard
                    key={document.id}
                    document={document}
                    onDelete={handleDelete}
                    onDownload={handleDownload}
                    onEdit={handleEdit}
                  />
                ))}
              </div>
            )}
          </>
        );

      case 'team':
        return (
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-6">Team Management</h1>
            <StaffManagementModal
              isOpen={true}
              onClose={() => setActiveTab('dashboard')}
            />
          </div>
        );

      case 'settings':
        return (
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-6">Settings</h1>
            <SettingsPage onToast={showToast} />
          </div>
        );

      case 'profile':
        return (
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-6">My Profile</h1>
            <ProfilePage />
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-50">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>

      <ComprehensiveUploadModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onSuccess={() => {
          loadDocuments();
          showToast('Document uploaded successfully', 'success');
        }}
      />

      {editingDocument && (
        <EditDocumentModal
          isOpen={showEditModal}
          onClose={() => {
            setShowEditModal(false);
            setEditingDocument(null);
          }}
          onSuccess={() => {
            loadDocuments();
            showToast('Document updated successfully', 'success');
          }}
          document={editingDocument}
        />
      )}

      {activeTab !== 'team' && (
        <StaffManagementModal
          isOpen={showStaffModal}
          onClose={() => setShowStaffModal(false)}
        />
      )}

      <ToastContainer toasts={toasts} onClose={removeToast} />
    </div>
  );
}
