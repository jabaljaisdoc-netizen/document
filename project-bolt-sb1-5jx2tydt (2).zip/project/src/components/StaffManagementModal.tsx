import { useState, useEffect } from 'react';
import { X, UserPlus, Mail, Shield, User, Trash2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, StaffProfile } from '../lib/supabase';

interface StaffManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function StaffManagementModal({ isOpen, onClose }: StaffManagementModalProps) {
  const { signUp } = useAuth();
  const [staff, setStaff] = useState<StaffProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    role: 'staff' as 'admin' | 'staff'
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadStaff();
    }
  }, [isOpen]);

  const loadStaff = async () => {
    const { data, error } = await supabase
      .from('staff_profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading staff:', error);
    } else {
      setStaff(data || []);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const { error } = await signUp(
      formData.email,
      formData.password,
      formData.fullName,
      formData.role
    );

    if (error) {
      setError(error.message || 'Failed to create staff member');
    } else {
      setFormData({
        email: '',
        password: '',
        fullName: '',
        role: 'staff'
      });
      setShowAddForm(false);
      loadStaff();
    }

    setLoading(false);
  };

  const handleToggleActive = async (staffId: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from('staff_profiles')
      .update({ is_active: !currentStatus })
      .eq('id', staffId);

    if (error) {
      console.error('Error updating staff status:', error);
    } else {
      loadStaff();
    }
  };

  const handleDelete = async (staffId: string) => {
    if (!confirm('Are you sure you want to delete this staff member? This will permanently delete their account, profile, and all authentication credentials.')) {
      return;
    }

    setLoading(true);
    setError('');

    try {
      const { data: staffMember } = await supabase
        .from('staff_profiles')
        .select('email')
        .eq('id', staffId)
        .single();

      const { error: deleteProfileError } = await supabase
        .from('staff_profiles')
        .delete()
        .eq('id', staffId);

      if (deleteProfileError) throw deleteProfileError;

      const { error: deleteAuthError } = await supabase.auth.admin.deleteUser(staffId);

      if (deleteAuthError) {
        console.error('Error deleting auth user:', deleteAuthError);
      }

      await loadStaff();
    } catch (err) {
      console.error('Error deleting staff:', err);
      setError('Failed to delete staff member completely. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-900">Staff Management</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          {!showAddForm ? (
            <div className="mb-6">
              <button
                onClick={() => setShowAddForm(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                <UserPlus className="h-4 w-4" />
                Add Staff Member
              </button>
            </div>
          ) : (
            <div className="mb-6 p-6 bg-slate-50 rounded-xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-slate-900">Add New Staff Member</h3>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setError('');
                  }}
                  className="text-slate-500 hover:text-slate-700"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    required
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="John Doe"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="john@company.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    required
                    minLength={6}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="Minimum 6 characters"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Role
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as 'admin' | 'staff' })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  >
                    <option value="staff">Staff</option>
                    <option value="admin">Admin</option>
                  </select>
                  <p className="text-xs text-slate-500 mt-1">
                    Admins can manage other staff members
                  </p>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddForm(false);
                      setError('');
                    }}
                    className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Adding...' : 'Add Staff Member'}
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Staff Members</h3>

            {staff.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-lg">
                <User className="h-12 w-12 text-slate-300 mx-auto mb-2" />
                <p className="text-slate-600">No staff members found</p>
              </div>
            ) : (
              staff.map((member) => (
                <div
                  key={member.id}
                  className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${member.is_active ? 'bg-blue-100' : 'bg-slate-100'}`}>
                        <User className={`h-5 w-5 ${member.is_active ? 'text-blue-600' : 'text-slate-400'}`} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-900">{member.full_name}</h4>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-1 text-sm text-slate-600">
                            <Shield className="h-3 w-3" />
                            <span className="capitalize">{member.role}</span>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            member.is_active
                              ? 'bg-green-100 text-green-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {member.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleActive(member.id, member.is_active)}
                        className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                          member.is_active
                            ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            : 'bg-green-100 text-green-700 hover:bg-green-200'
                        }`}
                      >
                        {member.is_active ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        onClick={() => handleDelete(member.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
