import { useState } from 'react';
import { Bell, X } from 'lucide-react';
import { Document } from '../lib/supabase';
import { format, isPast } from 'date-fns';

interface NotificationBellProps {
  documents: Document[];
}

export default function NotificationBell({ documents }: NotificationBellProps) {
  const [showPanel, setShowPanel] = useState(false);

  const activeNotifications = documents.filter((doc) => {
    if (!doc.notification_date) return false;
    return isPast(new Date(doc.notification_date)) && !doc.email_sent;
  });

  const hasNotifications = activeNotifications.length > 0;

  return (
    <div className="relative">
      <button
        onClick={() => setShowPanel(!showPanel)}
        className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
      >
        <Bell className="h-6 w-6" />
        {hasNotifications && (
          <span className="absolute top-1 right-1 h-2.5 w-2.5 bg-red-500 rounded-full ring-2 ring-white"></span>
        )}
      </button>

      {showPanel && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setShowPanel(false)}
          ></div>
          <div className="absolute right-0 mt-2 w-96 bg-white rounded-xl shadow-xl border border-slate-200 z-50 max-h-96 overflow-y-auto">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white">
              <h3 className="font-semibold text-slate-900">Notifications</h3>
              <button
                onClick={() => setShowPanel(false)}
                className="p-1 hover:bg-slate-100 rounded transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {activeNotifications.length === 0 ? (
              <div className="p-8 text-center">
                <Bell className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500 text-sm">No new notifications</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {activeNotifications.map((doc) => (
                  <div key={doc.id} className="p-4 hover:bg-slate-50 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-amber-100 rounded-lg">
                        <Bell className="h-4 w-4 text-amber-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-900 mb-1">
                          {doc.client_name || 'Client'}
                        </p>
                        <p className="text-xs text-slate-600 mb-2">
                          {doc.doc_type} expires on{' '}
                          {format(new Date(doc.expiry_date), 'MMM dd, yyyy')}
                        </p>
                        <p className="text-xs text-slate-500">
                          Notification date: {format(new Date(doc.notification_date), 'MMM dd, yyyy')}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
