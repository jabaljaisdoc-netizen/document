import { FileText, AlertTriangle, CheckCircle } from 'lucide-react';
import { Document } from '../lib/supabase';
import { differenceInDays } from 'date-fns';

interface StatsBarProps {
  documents: Document[];
}

export default function StatsBar({ documents }: StatsBarProps) {
  const today = new Date();

  const criticalCount = documents.filter((doc) => {
    const daysUntilExpiry = differenceInDays(new Date(doc.expiry_date), today);
    return daysUntilExpiry < 7 && daysUntilExpiry >= 0;
  }).length;

  const safeCount = documents.filter((doc) => {
    const daysUntilExpiry = differenceInDays(new Date(doc.expiry_date), today);
    return daysUntilExpiry > 30;
  }).length;

  const stats = [
    {
      label: 'Total Documents',
      value: documents.length,
      icon: FileText,
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      textColor: 'text-blue-900',
    },
    {
      label: 'Critical',
      value: criticalCount,
      subtitle: 'Expires < 7 days',
      icon: AlertTriangle,
      bgColor: 'bg-red-50',
      iconColor: 'text-red-600',
      textColor: 'text-red-900',
    },
    {
      label: 'Safe',
      value: safeCount,
      subtitle: 'Expires > 30 days',
      icon: CheckCircle,
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
      textColor: 'text-green-900',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className={`${stat.bgColor} rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow`}
        >
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm font-medium text-slate-600 mb-2">{stat.label}</p>
              <p className={`text-4xl font-bold ${stat.textColor} mb-1`}>{stat.value}</p>
              {stat.subtitle && (
                <p className="text-xs text-slate-500 font-medium">{stat.subtitle}</p>
              )}
            </div>
            <div className={`p-3 rounded-xl ${stat.bgColor} ring-2 ring-white`}>
              <stat.icon className={`h-6 w-6 ${stat.iconColor}`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
