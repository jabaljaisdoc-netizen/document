import { User, Mail, Shield, Calendar } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';

export default function ProfilePage() {
  const { user, profile } = useAuth();

  return (
    <div className="max-w-3xl">
      <div className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-12 text-white">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-white/20 rounded-2xl backdrop-blur">
              <User className="h-12 w-12" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{profile?.full_name}</h1>
              <p className="text-blue-100 mt-1 capitalize">{profile?.role}</p>
            </div>
          </div>
        </div>

        <div className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Mail className="h-5 w-5 text-blue-600" />
                </div>
                <h3 className="font-semibold text-slate-900">Email</h3>
              </div>
              <p className="text-slate-700">{user?.email}</p>
            </div>

            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Shield className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="font-semibold text-slate-900">Role</h3>
              </div>
              <p className="text-slate-700 capitalize">{profile?.role}</p>
            </div>

            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Calendar className="h-5 w-5 text-purple-600" />
                </div>
                <h3 className="font-semibold text-slate-900">Member Since</h3>
              </div>
              <p className="text-slate-700">
                {profile?.created_at
                  ? format(new Date(profile.created_at), 'MMMM dd, yyyy')
                  : 'N/A'}
              </p>
            </div>

            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 bg-amber-100 rounded-lg">
                  <User className="h-5 w-5 text-amber-600" />
                </div>
                <h3 className="font-semibold text-slate-900">Status</h3>
              </div>
              <div className="flex items-center gap-2">
                <div
                  className={`h-2 w-2 rounded-full ${
                    profile?.is_active ? 'bg-green-500' : 'bg-red-500'
                  }`}
                ></div>
                <p className="text-slate-700">{profile?.is_active ? 'Active' : 'Inactive'}</p>
              </div>
            </div>
          </div>

          {profile?.role === 'admin' && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <h3 className="font-semibold text-blue-900 mb-2">Admin Privileges</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• View all documents uploaded by any staff member</li>
                <li>• Manage team members and add new staff</li>
                <li>• Configure system settings and notifications</li>
                <li>• Full access to all features and reports</li>
              </ul>
            </div>
          )}

          {profile?.role === 'staff' && (
            <div className="bg-green-50 border border-green-200 rounded-xl p-6">
              <h3 className="font-semibold text-green-900 mb-2">Staff Privileges</h3>
              <ul className="text-sm text-green-800 space-y-1">
                <li>• View documents you have uploaded</li>
                <li>• Upload and manage your own documents</li>
                <li>• Send WhatsApp notifications to clients</li>
                <li>• Access your personal dashboard</li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
