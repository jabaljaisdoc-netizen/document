import { useState, useEffect } from 'react';
import { X, Save, FileText, XCircle } from 'lucide-react';
import { supabase, Document } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { subWeeks, subMonths, format } from 'date-fns';

interface EditDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  document: Document;
}

export default function EditDocumentModal({
  isOpen,
  onClose,
  onSuccess,
  document,
}: EditDocumentModalProps) {
  const { profile } = useAuth();
  const [clientName, setClientName] = useState(document.client_name || '');
  const [clientPhone, setClientPhone] = useState(document.client_phone || '');
  const [docType, setDocType] = useState(document.doc_type || 'Visa');
  const [otherDocType, setOtherDocType] = useState('');
  const [expiryDate, setExpiryDate] = useState(document.expiry_date);
  const [reminderSetting, setReminderSetting] = useState(document.reminder_setting || '1 Week Before');
  const [customDate, setCustomDate] = useState(document.notification_date || '');
  const [notes, setNotes] = useState(document.notes || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const docTypes = ['Visa', 'License', 'Insurance', 'Passport', 'Other'];
  const reminderOptions = ['1 Week Before', '2 Weeks Before', '1 Month Before', 'Custom Date'];

  useEffect(() => {
    if (document.doc_type === 'Other' || !docTypes.includes(document.doc_type || '')) {
      setDocType('Other');
      setOtherDocType(document.doc_type || '');
    }
  }, [document]);

  const calculateNotificationDate = (): string | null => {
    if (!expiryDate) return null;

    const expiry = new Date(expiryDate);

    switch (reminderSetting) {
      case '1 Week Before':
        return format(subWeeks(expiry, 1), 'yyyy-MM-dd');
      case '2 Weeks Before':
        return format(subWeeks(expiry, 2), 'yyyy-MM-dd');
      case '1 Month Before':
        return format(subMonths(expiry, 1), 'yyyy-MM-dd');
      case 'Custom Date':
        return customDate || null;
      default:
        return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (document.status === 'cancelled') {
        const { error: updateError } = await supabase
          .from('documents')
          .update({
            notes: notes,
          })
          .eq('id', document.id);

        if (updateError) throw updateError;

        onSuccess();
        onClose();
        return;
      }

      if (!clientName || !expiryDate) {
        throw new Error('Please fill in all required fields');
      }

      const finalDocType = docType === 'Other' ? otherDocType : docType;

      if (docType === 'Other' && !otherDocType.trim()) {
        throw new Error('Please specify the document type');
      }

      const notificationDate = calculateNotificationDate();
      const cleanedPhone = clientPhone.replace(/\s+/g, '');

      const { error: updateError } = await supabase
        .from('documents')
        .update({
          client_name: clientName,
          client_phone: cleanedPhone,
          doc_type: finalDocType,
          document_name: finalDocType,
          expiry_date: expiryDate,
          reminder_setting: reminderSetting,
          notification_date: notificationDate,
          notes: notes,
          email_sent: false,
        })
        .eq('id', document.id);

      if (updateError) throw updateError;

      onSuccess();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update document');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setError('');
    onClose();
  };

  const handleCancelDocument = async () => {
    if (!confirm('Are you sure you want to cancel this document? This action marks it as cancelled.')) return;

    setLoading(true);
    try {
      const { error: updateError } = await supabase
        .from('documents')
        .update({ status: 'cancelled' })
        .eq('id', document.id);

      if (updateError) throw updateError;

      onSuccess();
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to cancel document');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className={`sticky top-0 px-6 py-5 flex items-center justify-between rounded-t-2xl ${
          document.status === 'cancelled'
            ? 'bg-gradient-to-r from-gray-600 to-gray-700'
            : 'bg-gradient-to-r from-green-600 to-green-700'
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <FileText className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">
              {document.status === 'cancelled' ? 'View Cancelled Document' : 'Edit Document'}
            </h2>
          </div>
          <button onClick={handleClose} className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 text-red-700 px-4 py-3 rounded">
              <p className="font-medium">Error</p>
              <p className="text-sm">{error}</p>
            </div>
          )}

          {document.status === 'cancelled' && (
            <div className="bg-gray-50 border-l-4 border-gray-500 text-gray-700 px-4 py-3 rounded mb-4">
              <p className="font-medium">This document is cancelled</p>
              <p className="text-sm">You can only update the notes field to add cancellation reasons or remarks.</p>
            </div>
          )}

          {document.status !== 'cancelled' && (
            <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Client Name *
              </label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                required
                placeholder="Enter client name"
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Client Phone *
              </label>
              <input
                type="tel"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                required
                placeholder="+971 50 123 4567"
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Document Type *
              </label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              >
                {docTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>

              {docType === 'Other' && (
                <input
                  type="text"
                  value={otherDocType}
                  onChange={(e) => setOtherDocType(e.target.value)}
                  required={docType === 'Other'}
                  placeholder="Specify document type"
                  className="mt-3 w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                />
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Expiry Date *
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                required
                className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Reminder Trigger *
            </label>
            <select
              value={reminderSetting}
              onChange={(e) => setReminderSetting(e.target.value)}
              required
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
            >
              {reminderOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>

            {reminderSetting === 'Custom Date' && (
              <div className="mt-3">
                <label className="block text-sm font-semibold text-slate-700 mb-2">
                  Notification Date *
                </label>
                <input
                  type="date"
                  value={customDate}
                  onChange={(e) => setCustomDate(e.target.value)}
                  required={reminderSetting === 'Custom Date'}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                />
              </div>
            )}

            {expiryDate && reminderSetting !== 'Custom Date' && (
              <p className="text-sm text-slate-600 mt-2">
                Notification will be sent on:{' '}
                <span className="font-semibold">
                  {calculateNotificationDate()
                    ? format(new Date(calculateNotificationDate()!), 'MMM dd, yyyy')
                    : 'N/A'}
                </span>
              </p>
            )}
          </div>
          </>
          )}

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              {document.status === 'cancelled' ? 'Notes / Cancellation Reason *' : 'Notes (Optional)'}
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={document.status === 'cancelled' ? 6 : 3}
              placeholder={document.status === 'cancelled' ? 'Add the reason for cancellation or remarks...' : 'Add any additional notes or comments'}
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none resize-none"
            />
          </div>

          <div className="flex gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 px-6 py-3 border-2 border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-xl font-semibold hover:from-green-700 hover:to-green-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {document.status === 'cancelled' ? 'Updating...' : 'Saving...'}
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  {document.status === 'cancelled' ? 'Update Notes' : 'Save Changes'}
                </>
              )}
            </button>
          </div>
          {document.status !== 'cancelled' && (
            <button
              type="button"
              onClick={handleCancelDocument}
              disabled={loading}
              className="w-full px-6 py-3 bg-gray-600 text-white rounded-xl font-semibold hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mt-3"
            >
              <XCircle className="h-5 w-5" />
              Cancel Document
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
