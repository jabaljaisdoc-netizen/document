import { useState, useEffect } from 'react';
import { FileText, Upload, LogOut, Users, Filter, Search } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Document } from '../lib/supabase';
import DocumentCard from './DocumentCard';
import UploadDocumentModal from './UploadDocumentModal';
import StaffManagementModal from './StaffManagementModal';

export default function Dashboard() {
  const { profile, signOut } = useAuth();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [filteredDocuments, setFilteredDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadDocuments();
  }, []);

  useEffect(() => {
    filterDocuments();
  }, [documents, filterStatus, searchQuery]);

  const loadDocuments = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('documents')
      .select(`
        *,
        clients (
          id,
          name,
          email,
          phone
        )
      `)
      .order('expiry_date', { ascending: true });

    if (error) {
      console.error('Error loading documents:', error);
    } else {
      setDocuments(data || []);
    }
    setLoading(false);
  };

  const filterDocuments = () => {
    let filtered = documents;

    if (filterStatus !== 'all') {
      filtered = filtered.filter((doc) => doc.status === filterStatus);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (doc) =>
          doc.document_name.toLowerCase().includes(query) ||
          doc.clients?.name.toLowerCase().includes(query) ||
          doc.document_number?.toLowerCase().includes(query)
      );
    }

    setFilteredDocuments(filtered);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this document?')) return;

    const doc = documents.find((d) => d.id === id);
    if (doc?.file_url) {
      await supabase.storage.from('documents').remove([doc.file_url]);
    }

    const { error } = await supabase.from('documents').delete().eq('id', id);

    if (error) {
      console.error('Error deleting document:', error);
    } else {
      loadDocuments();
    }
  };

  const handleDownload = async (fileUrl: string, fileName: string) => {
    const { data, error } = await supabase.storage.from('documents').download(fileUrl);

    if (error) {
      console.error('Error downloading file:', error);
      return;
    }

    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getStatusCounts = () => {
    return {
      all: documents.length,
      expired: documents.filter((d) => d.status === 'expired').length,
      expiring_soon: documents.filter((d) => d.status === 'expiring_soon').length,
      valid: documents.filter((d) => d.status === 'valid').length
    };
  };

  const counts = getStatusCounts();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Document Manager</h1>
                <p className="text-sm text-slate-600">Welcome back, {profile?.full_name}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowUploadModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                <Upload className="h-4 w-4" />
                Upload Document
              </button>

              {profile?.role === 'admin' && (
                <button
                  onClick={() => setShowStaffModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-600 text-white rounded-lg font-medium hover:bg-slate-700 transition-colors"
                >
                  <Users className="h-4 w-4" />
                  Manage Staff
                </button>
              )}

              <button
                onClick={signOut}
                className="flex items-center gap-2 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <button
            onClick={() => setFilterStatus('all')}
            className={`p-4 rounded-xl transition-all ${
              filterStatus === 'all'
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-white text-slate-700 hover:shadow-md'
            }`}
          >
            <div className="text-3xl font-bold">{counts.all}</div>
            <div className="text-sm mt-1 opacity-90">Total Documents</div>
          </button>

          <button
            onClick={() => setFilterStatus('expired')}
            className={`p-4 rounded-xl transition-all ${
              filterStatus === 'expired'
                ? 'bg-red-600 text-white shadow-lg'
                : 'bg-white text-slate-700 hover:shadow-md'
            }`}
          >
            <div className="text-3xl font-bold">{counts.expired}</div>
            <div className="text-sm mt-1 opacity-90">Expired</div>
          </button>

          <button
            onClick={() => setFilterStatus('expiring_soon')}
            className={`p-4 rounded-xl transition-all ${
              filterStatus === 'expiring_soon'
                ? 'bg-amber-600 text-white shadow-lg'
                : 'bg-white text-slate-700 hover:shadow-md'
            }`}
          >
            <div className="text-3xl font-bold">{counts.expiring_soon}</div>
            <div className="text-sm mt-1 opacity-90">Expiring Soon</div>
          </button>

          <button
            onClick={() => setFilterStatus('valid')}
            className={`p-4 rounded-xl transition-all ${
              filterStatus === 'valid'
                ? 'bg-green-600 text-white shadow-lg'
                : 'bg-white text-slate-700 hover:shadow-md'
            }`}
          >
            <div className="text-3xl font-bold">{counts.valid}</div>
            <div className="text-sm mt-1 opacity-90">Valid</div>
          </button>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by document name, client, or document number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-slate-600">Loading documents...</p>
          </div>
        ) : filteredDocuments.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl">
            <FileText className="h-16 w-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-700 mb-2">No documents found</h3>
            <p className="text-slate-500">
              {searchQuery || filterStatus !== 'all'
                ? 'Try adjusting your filters or search query'
                : 'Upload your first document to get started'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDocuments.map((document) => (
              <DocumentCard
                key={document.id}
                document={document}
                onDelete={handleDelete}
                onDownload={handleDownload}
              />
            ))}
          </div>
        )}
      </main>

      <UploadDocumentModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onSuccess={loadDocuments}
      />

      <StaffManagementModal
        isOpen={showStaffModal}
        onClose={() => setShowStaffModal(false)}
      />
    </div>
  );
}
