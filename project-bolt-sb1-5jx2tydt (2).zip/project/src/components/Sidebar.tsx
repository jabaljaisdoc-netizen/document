import { Home, Upload, Users, Settings, User, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const { profile, signOut } = useAuth();
  const isAdmin = profile?.role === 'admin';

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, show: true },
    { id: 'uploads', label: 'My Uploads', icon: Upload, show: true },
    { id: 'team', label: 'Team Management', icon: Users, show: isAdmin },
    { id: 'settings', label: 'Settings', icon: Settings, show: isAdmin },
    { id: 'profile', label: 'Profile', icon: User, show: true },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 min-h-screen flex flex-col">
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <img
            src="/Gemini_Generated_Image_97uvc897uvc897uv copy copy copy.png"
            alt="FluxFile"
            className="h-10 w-10 object-contain"
          />
          <div>
            <h1 className="text-xl font-bold text-slate-900">FluxFile</h1>
            <p className="text-xs text-slate-500">Document Management</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) =>
          item.show ? (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all ${
                activeTab === item.id
                  ? 'bg-jdc-50 text-jdc-900 shadow-sm'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </button>
          ) : null
        )}
      </nav>

      <div className="p-4 border-t border-slate-200">
        <div className="mb-3 p-3 bg-slate-50 rounded-lg">
          <p className="text-xs text-slate-500 mb-1">Signed in as</p>
          <p className="text-sm font-semibold text-slate-900">{profile?.full_name}</p>
          <p className="text-xs text-slate-500 capitalize">{profile?.role}</p>
        </div>
        <button
          onClick={signOut}
          className="w-full flex items-center gap-3 px-4 py-2.5 text-slate-700 hover:bg-red-50 hover:text-red-600 rounded-lg font-medium transition-all"
        >
          <LogOut className="h-5 w-5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
