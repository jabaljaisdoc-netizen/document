import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://cadysragerkgidfivcld.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNhZHlzcmFnZXJrZ2lkZml2Y2xkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQzMzMyMTAsImV4cCI6MjA3OTkwOTIxMH0.dLpaMQY5x-_GmoDHCwGLOEPYvhgP5Me-1gFs0rQvFBQ';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Client {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  created_at: string;
  updated_at: string;
}

export interface Document {
  id: string;
  client_id?: string;
  client_name?: string;
  client_phone?: string;
  doc_type?: string;
  document_name: string;
  document_number: string | null;
  file_url: string | null;
  file_name: string | null;
  expiry_date: string;
  issue_date: string | null;
  reminder_setting?: string;
  notification_date?: string | null;
  notes: string;
  status: 'valid' | 'expiring_soon' | 'expired';
  uploaded_by: string;
  uploaded_by_name?: string;
  email_sent?: boolean;
  created_at: string;
  updated_at: string;
  clients?: Client;
}

export interface Settings {
  id: string;
  admin_email: string;
  updated_at: string;
}

export interface StaffProfile {
  id: string;
  full_name: string;
  role: 'admin' | 'staff';
  is_active: boolean;
  created_at: string;
}
