-- ========================================
-- JDC Global Document Expiry Management
-- Quick Database Verification Script
-- ========================================

-- Run this entire script in your Supabase SQL Editor to verify everything is working

-- 1. CHECK ALL TABLES EXIST
-- Expected: 4 tables (clients, documents, settings, staff_profiles)
SELECT tablename
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;

-- 2. VERIFY RLS IS ENABLED ON ALL TABLES
-- Expected: All 4 tables should have rls_enabled = true
SELECT tablename, rowsecurity as rls_enabled
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;

-- 3. COUNT RLS POLICIES
-- Expected: clients(4), documents(4), settings(2), staff_profiles(6)
SELECT tablename,
       COUNT(*) as policy_count
FROM pg_policies
WHERE schemaname = 'public'
GROUP BY tablename
ORDER BY tablename;

-- 4. VIEW ALL STAFF MEMBERS
-- Shows all registered staff and their roles
SELECT
  id,
  full_name,
  role,
  is_active,
  created_at
FROM staff_profiles
ORDER BY created_at DESC;

-- 5. CHECK DOCUMENTS WITH STATUS
-- Shows document distribution by status
SELECT
  status,
  COUNT(*) as count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM documents), 1) as percentage
FROM documents
GROUP BY status
ORDER BY
  CASE status
    WHEN 'expired' THEN 1
    WHEN 'expiring_soon' THEN 2
    WHEN 'valid' THEN 3
  END;

-- 6. DOCUMENTS NEEDING ATTENTION
-- Shows documents that are expired or expiring soon
SELECT
  client_name,
  doc_type,
  document_name,
  expiry_date,
  status,
  CASE
    WHEN expiry_date < CURRENT_DATE THEN CURRENT_DATE - expiry_date
    ELSE 0
  END as days_past_expiry,
  notification_date,
  email_sent
FROM documents
WHERE status IN ('expired', 'expiring_soon')
ORDER BY expiry_date ASC;

-- 7. VERIFY SETTINGS TABLE
-- Check if admin email is configured
SELECT
  id,
  admin_email,
  CASE
    WHEN admin_email IS NOT NULL AND admin_email != '' THEN 'Configured'
    ELSE 'NOT CONFIGURED - Please set in Settings page'
  END as status,
  updated_at
FROM settings
WHERE id = 'global';

-- 8. PENDING EMAIL NOTIFICATIONS
-- Documents that should trigger notifications
SELECT
  client_name,
  doc_type,
  expiry_date,
  notification_date,
  email_sent,
  status,
  'Should send notification' as action
FROM documents
WHERE notification_date < CURRENT_DATE
  AND email_sent = false
  AND status IN ('expiring_soon', 'expired')
ORDER BY notification_date ASC;

-- 9. COMPREHENSIVE SYSTEM HEALTH CHECK
SELECT
  'Total Staff Members' as metric,
  COUNT(*)::text as value
FROM staff_profiles
UNION ALL
SELECT
  'Active Staff Members',
  COUNT(*)::text
FROM staff_profiles
WHERE is_active = true
UNION ALL
SELECT
  'Admin Users',
  COUNT(*)::text
FROM staff_profiles
WHERE role = 'admin' AND is_active = true
UNION ALL
SELECT
  'Total Clients',
  COUNT(*)::text
FROM clients
UNION ALL
SELECT
  'Total Documents',
  COUNT(*)::text
FROM documents
UNION ALL
SELECT
  'Valid Documents',
  COUNT(*)::text
FROM documents
WHERE status = 'valid'
UNION ALL
SELECT
  'Documents Expiring Soon',
  COUNT(*)::text
FROM documents
WHERE status = 'expiring_soon'
UNION ALL
SELECT
  'Expired Documents',
  COUNT(*)::text
FROM documents
WHERE status = 'expired'
UNION ALL
SELECT
  'Admin Email Configured',
  CASE
    WHEN EXISTS (
      SELECT 1 FROM settings
      WHERE id = 'global'
      AND admin_email IS NOT NULL
      AND admin_email != ''
    ) THEN 'Yes ✓'
    ELSE 'No - Please configure in Settings'
  END
FROM (SELECT 1) as dummy;

-- 10. TEST AUTHENTICATION QUERY
-- This mimics what the app does when you login
-- Replace 'YOUR-USER-ID' with an actual user ID from staff_profiles
SELECT
  sp.id,
  sp.full_name,
  sp.role,
  sp.is_active,
  COUNT(d.id) as documents_uploaded
FROM staff_profiles sp
LEFT JOIN documents d ON d.uploaded_by = sp.id
-- WHERE sp.id = 'YOUR-USER-ID'  -- Uncomment and replace with real ID
GROUP BY sp.id, sp.full_name, sp.role, sp.is_active
LIMIT 5;

-- ========================================
-- VERIFICATION COMPLETE
-- ========================================
-- If all queries run successfully, your database is properly configured!
--
-- Next Steps:
-- 1. Ensure admin email is set in Settings page
-- 2. Add staff members through Team Management
-- 3. Start uploading documents
-- 4. Monitor notifications for expiring documents
-- ========================================
