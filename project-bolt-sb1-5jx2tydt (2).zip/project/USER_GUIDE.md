# JDC Global Document Expiry Management System - User Guide

## 🎯 Quick Start

### First Time Setup (Admin Only)

1. **Login** with your admin credentials
2. **Go to Settings** (sidebar menu)
3. **Enter Admin Email** for receiving expiry notifications
4. **Save Settings**
5. **Add Staff Members** via Team Management (if needed)

## 👥 User Roles

### Admin
- Full access to all features
- Can add/remove staff members
- Can configure system settings
- Can view all documents
- Manages team and system

### Staff
- Can upload documents
- Can view all documents
- Can edit/delete their own uploads
- Can update their profile
- Cannot manage other staff or settings

## 📋 Main Features

### 1. Dashboard (Home)
Your central hub for document tracking.

**What You'll See:**
- **Stats Bar**: Total documents, expiring soon, expired counts
- **Quick Filters**: All, Valid, Expiring Soon, Expired
- **Search Bar**: Search by client name or document type
- **Document Cards**: Visual cards showing document status
- **Notification Bell**: Click to see active notifications

**Status Colors:**
- 🟢 **Green** = Valid (30+ days until expiry)
- 🟡 **Yellow** = Expiring Soon (less than 30 days)
- 🔴 **Red** = Expired (past expiry date)

### 2. Upload Documents

**Click the "+ Upload Document" button**

**Required Information:**
- Client Name, Phone, Email
- Document Type (Passport, Visa, License, etc.)
- Document Name
- Document Number (optional)
- Issue Date (optional)
- Expiry Date (required)
- Reminder Setting (30, 60, or 90 days before expiry)
- Notes (optional)

**How Reminders Work:**
The system calculates a notification date based on your reminder setting. For example:
- Expiry Date: June 30, 2025
- Reminder: 30 days before
- Notification Date: May 31, 2025

On May 31, 2025, the system will show a notification and (if configured) send an email to the admin.

### 3. My Uploads
View all documents you've personally uploaded. Perfect for tracking your work.

### 4. Document Actions

**Each document card has action buttons:**

**📝 Edit**: Modify document details
- Update expiry dates
- Change reminder settings
- Add/edit notes
- Update client information

**🗑️ Delete**: Remove document (cannot be undone)
- Confirmation required
- Only available for your uploads (or if you're admin)

### 5. Search & Filter

**Search:**
Type in the search bar to filter by:
- Client name
- Document type
- Document name

**Quick Filters:**
- **All**: Show everything
- **Valid**: Only valid documents
- **Expiring Soon**: Documents expiring within 30 days
- **Expired**: Already expired documents

### 6. Notifications

**Bell Icon** (top right):
- Red dot = New notifications
- Click to see pending notifications
- Shows documents that need attention

**What Triggers Notifications:**
- Document's notification date has passed
- Document hasn't been marked as email sent
- Document is expiring soon or expired

### 7. Team Management (Admin Only)

**Add New Staff:**
1. Click "Add Staff Member"
2. Enter full name, email, password
3. Select role (Admin or Staff)
4. Click "Add Staff Member"

**Manage Existing Staff:**
- **Activate/Deactivate**: Toggle staff access
- **Delete**: Remove staff member permanently
- **View Details**: See role and status

### 8. Settings (Admin Only)

**Admin Notification Email:**
Enter the email address that should receive notifications when documents are expiring or expired.

**Important:** This is currently simulated with toast messages in the app. Real email integration can be added in production.

### 9. Profile

Update your personal information:
- Full name
- View your role
- See account creation date

## 🔔 Understanding Notifications

### How It Works:

1. **Upload Document** with expiry date and reminder setting
2. **System Calculates** notification date (expiry date minus reminder days)
3. **On Notification Date**, system checks every time dashboard loads
4. **If Conditions Met**:
   - Notification date has passed
   - Email not yet sent
   - Document expiring soon or expired
5. **Toast Notification Appears**: "Simulating email to [admin@email.com] for [Client Name] - [Doc Type] expiring soon"
6. **Email Sent Flag Set** to prevent duplicate notifications

### Testing Notifications:

**Quick Test:**
1. Go to Settings, enter an admin email
2. Upload a document with:
   - Expiry Date: 15 days from today
   - Reminder: 30 days before (this makes notification date in the past)
3. Reload the dashboard
4. You should see a notification toast

**Or Edit Existing Document:**
1. Click Edit on any document
2. Set notification date to yesterday
3. Ensure "Email Sent" is unchecked
4. Save and reload dashboard
5. Notification should appear

## 📊 Dashboard Insights

### Status Distribution:
- **Green progress bar** = Valid documents percentage
- **Yellow progress bar** = Expiring soon percentage
- **Red progress bar** = Expired documents percentage

### Quick Actions:
- Click any filter to focus on specific documents
- Use search to find specific clients or document types
- Sort by expiry date (automatically sorted, soonest first)

## 🎨 JDC Global Branding

The application features JDC Global branding throughout:
- Logo in sidebar footer: "Powered by JDC Global"
- Logo on login page
- Custom color scheme matching JDC Global identity
- Professional document clearing company aesthetic

## 💡 Best Practices

### For Staff:
1. **Upload documents promptly** when received
2. **Set appropriate reminder dates** (usually 30-60 days before expiry)
3. **Add detailed notes** to help identify documents later
4. **Keep client information accurate** for contact purposes
5. **Check dashboard daily** for expiring documents

### For Admins:
1. **Configure admin email first** for notifications
2. **Add all team members** with correct roles
3. **Review expired documents** regularly
4. **Monitor dashboard statistics** to track workload
5. **Train staff** on proper document entry

## ❓ Troubleshooting

### Can't Login?
- Verify your email and password
- Check with admin if your account is active
- Ensure you're using the correct credentials

### Don't See Documents?
- Check active filters (might be filtering out documents)
- Clear search query
- Verify documents exist in the system

### Notifications Not Appearing?
- Check Settings - ensure admin email is configured
- Verify document has notification date set
- Ensure notification date is in the past
- Check that "Email Sent" is false

### Can't See Staff Management?
- This feature is admin-only
- Contact your administrator for access

### Can't Delete Documents?
- You can only delete your own uploads (unless you're admin)
- Admins can delete any document
- Deletion is permanent and cannot be undone

## 📞 Support

For technical issues or questions:
1. Check this user guide
2. Review `IMPLEMENTATION_SUMMARY.md` for technical details
3. Contact your system administrator
4. Check browser console for error messages

## 🚀 Tips for Power Users

**Keyboard Navigation:**
- Press Tab to move between form fields
- Press Enter to submit forms
- Press Escape to close modals

**Efficient Document Entry:**
1. Keep client database updated
2. Use consistent document type naming
3. Add meaningful notes for future reference
4. Set realistic reminder dates
5. Batch process similar documents

**Dashboard Efficiency:**
1. Use quick filters to focus work
2. Search by client for related documents
3. Sort by expiry to prioritize urgent items
4. Check notification bell first thing each day

---

**Powered by JDC Global** - Professional Document Clearing Services
