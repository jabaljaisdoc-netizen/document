/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        jdc: {
          50: '#f0f7ff',
          100: '#e0effe',
          200: '#b9ddfe',
          300: '#7cc2fd',
          400: '#36a4fa',
          500: '#0c8aeb',
          600: '#006ec9',
          700: '#0158a3',
          800: '#064a86',
          900: '#0a2540',
          950: '#071a2e',
        },
      },
    },
  },
  plugins: [],
};
