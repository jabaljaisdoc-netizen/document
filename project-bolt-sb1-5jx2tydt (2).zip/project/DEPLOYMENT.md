# Deployment Guide - Netlify

## Prerequisites

Before deploying to Netlify, ensure you have:
1. A Netlify account
2. Your Supabase project URL and Anon Key
3. Completed the database migrations

## Step-by-Step Deployment

### 1. Configure Environment Variables in Netlify

**IMPORTANT**: You must set these environment variables in Netlify before deployment:

1. Go to your Netlify site dashboard
2. Navigate to **Site settings** → **Environment variables**
3. Add the following variables:

```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

**To find your Supabase credentials:**
- Go to your Supabase project dashboard
- Click on **Settings** → **API**
- Copy the **Project URL** and **anon/public key**

### 2. Deploy to Netlify

#### Option A: Deploy from Git (Recommended)

1. Push your code to GitHub/GitLab/Bitbucket
2. Go to Netlify dashboard
3. Click **Add new site** → **Import an existing project**
4. Connect your Git provider
5. Select your repository
6. Netlify will auto-detect the build settings from `netlify.toml`
7. Click **Deploy site**

#### Option B: Deploy via Netlify CLI

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login to Netlify
netlify login

# Initialize and deploy
netlify init

# Or deploy directly
netlify deploy --prod
```

#### Option C: Manual Drag & Drop

1. Build your project locally:
   ```bash
   npm run build
   ```
2. Go to Netlify dashboard
3. Drag and drop the `dist` folder
4. **Note**: You'll still need to set environment variables in site settings

### 3. Verify Deployment

After deployment:
1. Visit your site URL
2. Try logging in with your admin credentials
3. Test creating and editing documents
4. Verify WhatsApp integration works
5. Check that role-based access control is functioning

## Build Configuration

The following configuration is already set up in `netlify.toml`:

```toml
[build]
  command = "npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"
```

## Troubleshooting

### Build Fails

**Issue**: "Something went wrong while creating your site on Netlify"

**Solutions**:
1. Ensure environment variables are set in Netlify dashboard
2. Check that Node version is 18 or higher
3. Verify all dependencies are in package.json
4. Check build logs for specific errors

### Environment Variables Not Working

**Issue**: App shows "Missing Supabase environment variables"

**Solutions**:
1. Double-check variable names (must be exactly `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`)
2. Redeploy after adding environment variables
3. Clear build cache and redeploy

### 404 on Routes

**Issue**: Refresh on any route except home shows 404

**Solution**:
- Already fixed! The `_redirects` file and `netlify.toml` configuration handle SPA routing

### Build Succeeds But App Is Blank

**Solutions**:
1. Check browser console for errors
2. Verify Supabase URL and keys are correct
3. Ensure CORS is properly configured in Supabase

## Post-Deployment Checklist

- [ ] Environment variables are set in Netlify
- [ ] Site deploys successfully
- [ ] Login page loads correctly
- [ ] Can login with admin/staff credentials
- [ ] Can create new documents
- [ ] Can edit existing documents
- [ ] WhatsApp integration works
- [ ] Role-based access control works (admin vs staff)
- [ ] Mobile responsive design works
- [ ] All navigation tabs are accessible

## Continuous Deployment

Once connected to Git:
- Every push to your main branch triggers automatic deployment
- Preview deployments are created for pull requests
- You can rollback to previous deployments anytime

## Custom Domain (Optional)

1. Go to **Site settings** → **Domain management**
2. Click **Add custom domain**
3. Follow instructions to configure DNS
4. SSL certificate will be provisioned automatically

## Performance Tips

- Netlify automatically enables:
  - Asset optimization
  - Compression (Brotli/Gzip)
  - Global CDN distribution
  - HTTP/2 push

- For better performance:
  - Use Netlify's image CDN for document thumbnails
  - Enable analytics to monitor performance
  - Consider Netlify Functions for serverless operations

## Security

The following security headers are already configured in `netlify.toml`:
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- Referrer-Policy: strict-origin-when-cross-origin
- Permissions-Policy restrictions

## Support

If you encounter issues:
1. Check Netlify build logs
2. Review browser console errors
3. Verify Supabase connection
4. Check that all migrations have been applied

## Environment Variables Reference

| Variable | Description | Required |
|----------|-------------|----------|
| `VITE_SUPABASE_URL` | Your Supabase project URL | Yes |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase anonymous/public key | Yes |

**Note**: Never commit these values to Git. They should only be set in Netlify's environment variable settings.
