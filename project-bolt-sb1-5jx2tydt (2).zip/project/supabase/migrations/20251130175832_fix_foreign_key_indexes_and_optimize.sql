/*
  # Fix Foreign Key Indexes and Optimize Database

  1. Index Improvements
    - Add indexes for all foreign key columns to improve query performance
    - Remove unused composite indexes that aren't being utilized
    - Create targeted indexes based on actual query patterns

  2. Performance Optimization
    - Index foreign keys: client_id, uploaded_by
    - Optimize for common query patterns in the application

  Note: Leaked Password Protection must be enabled manually in Supabase Dashboard
*/

-- Drop unused composite indexes that aren't being used
DROP INDEX IF EXISTS idx_documents_expiry_date_uploaded_by;
DROP INDEX IF EXISTS idx_staff_profiles_role_active;

-- Add index for documents.client_id foreign key
-- This improves JOIN performance with clients table
CREATE INDEX IF NOT EXISTS idx_documents_client_id 
  ON documents(client_id) 
  WHERE client_id IS NOT NULL;

-- Add index for documents.uploaded_by foreign key
-- This improves queries filtering by uploader and JOINs with staff_profiles
CREATE INDEX IF NOT EXISTS idx_documents_uploaded_by 
  ON documents(uploaded_by);

-- Add index for expiry_date (most common query pattern)
-- Used for filtering expiring/expired documents
CREATE INDEX IF NOT EXISTS idx_documents_expiry_date 
  ON documents(expiry_date);

-- Add index for notification_date (used in email notification checks)
CREATE INDEX IF NOT EXISTS idx_documents_notification_date 
  ON documents(notification_date) 
  WHERE notification_date IS NOT NULL 
  AND email_sent = false;

-- Add composite index for admin queries (view all documents by status)
CREATE INDEX IF NOT EXISTS idx_documents_status_expiry 
  ON documents(status, expiry_date);

-- Add index for staff_profiles active lookups
CREATE INDEX IF NOT EXISTS idx_staff_profiles_active 
  ON staff_profiles(is_active) 
  WHERE is_active = true;

-- Add index for role-based queries
CREATE INDEX IF NOT EXISTS idx_staff_profiles_role 
  ON staff_profiles(role);

-- Add comment explaining the indexing strategy
COMMENT ON TABLE documents IS 
'Indexes optimized for: 
- Foreign key relationships (client_id, uploaded_by)
- Expiry date filtering and sorting
- Notification date queries for email triggers
- Status-based filtering
- Role-based access control queries';

COMMENT ON TABLE staff_profiles IS 
'Indexes optimized for:
- Active staff lookups
- Role-based access control
- Authentication checks';