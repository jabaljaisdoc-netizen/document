/*
  # Add Admin Staff Management Policies

  1. Problem
    - Current RLS policies only allow users to view their own profile
    - Admins cannot view/manage other staff members
    - Staff list appears empty in the management modal

  2. Solution
    - Add SELECT policy allowing admins to view all staff profiles
    - Add UPDATE policy allowing admins to manage staff status
    - Maintain security by checking admin role

  3. Security
    - Only users with role='admin' can view all staff
    - Only admins can update other staff members
    - Regular staff can still only see their own profile
    - All policies check authentication and role
*/

-- Add policy for admins to view all staff profiles
CREATE POLICY "Admins can view all staff profiles"
  ON staff_profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = (SELECT auth.uid())
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  );

-- Add policy for admins to update any staff profile (for managing status, role, etc)
CREATE POLICY "Admins can update staff profiles"
  ON staff_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = (SELECT auth.uid())
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = (SELECT auth.uid())
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  );

-- Add policy for admins to delete staff
CREATE POLICY "Admins can delete staff profiles"
  ON staff_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles sp
      WHERE sp.id = (SELECT auth.uid())
      AND sp.role = 'admin'
      AND sp.is_active = true
    )
  );

-- Add comment explaining the admin access pattern
COMMENT ON TABLE staff_profiles IS 
'RLS Policies:
- Users can view/update their own profile
- Admins can view/update/delete all staff profiles
- Only active admins have management privileges';