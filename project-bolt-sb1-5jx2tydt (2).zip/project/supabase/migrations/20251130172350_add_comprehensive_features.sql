/*
  # Add Comprehensive Document Expiry Management Features

  1. New Tables
    - `settings`
      - `id` (text, primary key) - Always 'global'
      - `admin_email` (text) - Email for admin notifications
      - `updated_at` (timestamptz)

  2. Changes to Documents Table
    - Add `client_phone` (text) - For WhatsApp integration
    - Add `doc_type` (text) - Document type dropdown
    - Add `reminder_setting` (text) - Reminder trigger setting
    - Add `notification_date` (date) - Calculated notification date
    - Add `email_sent` (boolean) - Track if email notification sent
    - Add `uploaded_by_name` (text) - Staff name who uploaded

  3. Changes to Clients Table
    - Remove client table dependency and merge into documents

  4. Security
    - Enable RLS on settings table
    - Only admins can update settings
    - All staff can read settings
*/

-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
  id text PRIMARY KEY DEFAULT 'global',
  admin_email text DEFAULT '',
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Insert default settings
INSERT INTO settings (id, admin_email)
VALUES ('global', '')
ON CONFLICT (id) DO NOTHING;

-- RLS policies for settings
CREATE POLICY "All staff can view settings"
  ON settings FOR SELECT
  TO authenticated
  USING (is_active_staff());

CREATE POLICY "Admins can update settings"
  ON settings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = auth.uid()
      AND role = 'admin'
      AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = auth.uid()
      AND role = 'admin'
      AND is_active = true
    )
  );

-- Add new columns to documents table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'client_phone'
  ) THEN
    ALTER TABLE documents ADD COLUMN client_phone text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'doc_type'
  ) THEN
    ALTER TABLE documents ADD COLUMN doc_type text DEFAULT 'Other';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'reminder_setting'
  ) THEN
    ALTER TABLE documents ADD COLUMN reminder_setting text DEFAULT '1 Week Before';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'notification_date'
  ) THEN
    ALTER TABLE documents ADD COLUMN notification_date date;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'email_sent'
  ) THEN
    ALTER TABLE documents ADD COLUMN email_sent boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'uploaded_by_name'
  ) THEN
    ALTER TABLE documents ADD COLUMN uploaded_by_name text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'documents' AND column_name = 'client_name'
  ) THEN
    ALTER TABLE documents ADD COLUMN client_name text DEFAULT '';
  END IF;
END $$;

-- Update RLS policies for documents to support role-based viewing
DROP POLICY IF EXISTS "Active staff can view documents" ON documents;

-- Admins can view all documents
CREATE POLICY "Admins can view all documents"
  ON documents FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = auth.uid()
      AND role = 'admin'
      AND is_active = true
    )
  );

-- Staff can only view their own uploaded documents
CREATE POLICY "Staff can view own documents"
  ON documents FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = auth.uid()
      AND role = 'staff'
      AND is_active = true
    )
    AND uploaded_by = auth.uid()
  );

-- Create index for notification_date
CREATE INDEX IF NOT EXISTS idx_documents_notification_date ON documents(notification_date);

-- Create trigger to update settings updated_at
DROP TRIGGER IF EXISTS update_settings_updated_at ON settings;
CREATE TRIGGER update_settings_updated_at
  BEFORE UPDATE ON settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();