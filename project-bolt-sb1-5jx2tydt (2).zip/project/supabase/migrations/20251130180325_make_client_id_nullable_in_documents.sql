/*
  # Make client_id nullable in documents table

  1. Changes
    - Alter `documents.client_id` column to be nullable
    - This allows documents to be created without a formal client record
    - Client information is stored directly via client_name and client_phone fields

  2. Reasoning
    - The application stores client details (name, phone) directly in documents table
    - Not all documents need a formal client record in the clients table
    - This matches the actual usage pattern in the upload form
    - Maintains backward compatibility with existing documents that have client_id

  3. Security
    - No RLS policy changes needed
    - Existing policies continue to work correctly
*/

-- Make client_id nullable to support documents without formal client records
ALTER TABLE documents 
  ALTER COLUMN client_id DROP NOT NULL;

-- Add comment explaining the schema design
COMMENT ON COLUMN documents.client_id IS 
'Optional reference to clients table. Can be null if client info is stored directly in client_name/client_phone fields.';