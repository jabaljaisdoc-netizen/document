/*
  # Fix Documents and Clients RLS Policies

  1. Changes
    - Simplify RLS policies to avoid infinite recursion
    - Use a function to check if user is active staff
    - All authenticated users with staff profiles can access data

  2. Security
    - Maintains security by checking authentication
    - Simpler approach that avoids circular dependencies
*/

-- Create a function to check if user is active staff
CREATE OR REPLACE FUNCTION is_active_staff()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM staff_profiles
    WHERE id = auth.uid()
    AND is_active = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing policies for clients
DROP POLICY IF EXISTS "Authenticated staff can view all clients" ON clients;
DROP POLICY IF EXISTS "Authenticated staff can insert clients" ON clients;
DROP POLICY IF EXISTS "Authenticated staff can update clients" ON clients;
DROP POLICY IF EXISTS "Authenticated staff can delete clients" ON clients;

-- Create new simpler policies for clients
CREATE POLICY "Active staff can view clients"
  ON clients FOR SELECT
  TO authenticated
  USING (is_active_staff());

CREATE POLICY "Active staff can insert clients"
  ON clients FOR INSERT
  TO authenticated
  WITH CHECK (is_active_staff());

CREATE POLICY "Active staff can update clients"
  ON clients FOR UPDATE
  TO authenticated
  USING (is_active_staff())
  WITH CHECK (is_active_staff());

CREATE POLICY "Active staff can delete clients"
  ON clients FOR DELETE
  TO authenticated
  USING (is_active_staff());

-- Drop existing policies for documents
DROP POLICY IF EXISTS "Authenticated staff can view all documents" ON documents;
DROP POLICY IF EXISTS "Authenticated staff can insert documents" ON documents;
DROP POLICY IF EXISTS "Authenticated staff can update documents" ON documents;
DROP POLICY IF EXISTS "Authenticated staff can delete documents" ON documents;

-- Create new simpler policies for documents
CREATE POLICY "Active staff can view documents"
  ON documents FOR SELECT
  TO authenticated
  USING (is_active_staff());

CREATE POLICY "Active staff can insert documents"
  ON documents FOR INSERT
  TO authenticated
  WITH CHECK (is_active_staff());

CREATE POLICY "Active staff can update documents"
  ON documents FOR UPDATE
  TO authenticated
  USING (is_active_staff())
  WITH CHECK (is_active_staff());

CREATE POLICY "Active staff can delete documents"
  ON documents FOR DELETE
  TO authenticated
  USING (is_active_staff());