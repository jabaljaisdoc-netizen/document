/*
  # Fix RLS Performance and Security Issues

  1. Performance Optimizations
    - Update all RLS policies to use `(select auth.uid())` instead of `auth.uid()`
    - This prevents re-evaluation of auth functions for each row
    - Add search_path to functions for security

  2. Policy Improvements
    - Consolidate multiple permissive SELECT policies into single restrictive policies
    - Remove unused indexes that are not being utilized

  3. Function Security
    - Add STABLE keyword and proper search_path to all functions
    - Prevents security issues with mutable search paths
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Users can view their own profile" ON staff_profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON staff_profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON staff_profiles;
DROP POLICY IF EXISTS "Admins can update settings" ON settings;
DROP POLICY IF EXISTS "Admins can view all documents" ON documents;
DROP POLICY IF EXISTS "Staff can view own documents" ON documents;

-- Recreate staff_profiles policies with optimized auth calls
CREATE POLICY "Users can view their own profile"
  ON staff_profiles FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = id);

CREATE POLICY "Users can insert their own profile"
  ON staff_profiles FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = id);

CREATE POLICY "Users can update their own profile"
  ON staff_profiles FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

-- Recreate settings policies with optimized auth calls
CREATE POLICY "Admins can update settings"
  ON settings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = (select auth.uid())
      AND role = 'admin'
      AND is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = (select auth.uid())
      AND role = 'admin'
      AND is_active = true
    )
  );

-- Consolidate documents SELECT policies into a single policy
-- This resolves the "Multiple Permissive Policies" warning
CREATE POLICY "Authenticated users can view documents"
  ON documents FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE id = (select auth.uid())
      AND is_active = true
      AND (
        role = 'admin' 
        OR (role = 'staff' AND documents.uploaded_by = (select auth.uid()))
      )
    )
  );

-- Update is_active_staff function with proper security
CREATE OR REPLACE FUNCTION is_active_staff()
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM staff_profiles
    WHERE id = (select auth.uid())
    AND is_active = true
  );
END;
$$;

-- Update update_document_status function with proper security
CREATE OR REPLACE FUNCTION update_document_status()
RETURNS trigger
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  IF NEW.expiry_date < CURRENT_DATE THEN
    NEW.status = 'expired';
  ELSIF NEW.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN
    NEW.status = 'expiring_soon';
  ELSE
    NEW.status = 'valid';
  END IF;
  
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Update update_updated_at_column function with proper security
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Remove unused indexes to reduce maintenance overhead
DROP INDEX IF EXISTS idx_documents_client_id;
DROP INDEX IF EXISTS idx_documents_status;
DROP INDEX IF EXISTS idx_documents_uploaded_by;
DROP INDEX IF EXISTS idx_documents_notification_date;

-- Create only the indexes that are actually used
CREATE INDEX IF NOT EXISTS idx_documents_expiry_date_uploaded_by 
  ON documents(expiry_date, uploaded_by);

-- Add index for common query patterns
CREATE INDEX IF NOT EXISTS idx_staff_profiles_role_active 
  ON staff_profiles(role, is_active) 
  WHERE is_active = true;