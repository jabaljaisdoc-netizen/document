/*
  # Document Management System Schema

  1. New Tables
    - `clients`
      - `id` (uuid, primary key)
      - `name` (text) - Client/company name
      - `email` (text) - Client email
      - `phone` (text) - Client phone number
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `documents`
      - `id` (uuid, primary key)
      - `client_id` (uuid, foreign key)
      - `document_name` (text) - Name/type of document
      - `document_number` (text) - Document reference number
      - `file_url` (text) - Storage path for uploaded file
      - `file_name` (text) - Original file name
      - `expiry_date` (date) - Document expiration date
      - `issue_date` (date) - Document issue date
      - `notes` (text) - Additional notes
      - `status` (text) - valid, expiring_soon, expired
      - `uploaded_by` (uuid, foreign key to auth.users)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `staff_profiles`
      - `id` (uuid, primary key, references auth.users)
      - `full_name` (text)
      - `role` (text) - admin, staff
      - `is_active` (boolean)
      - `created_at` (timestamptz)

  2. Storage
    - Create storage bucket for document files

  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated staff users
    - Staff can view/manage all clients and documents
    - Only admins can manage other staff users
*/

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE NOT NULL,
  document_name text NOT NULL,
  document_number text,
  file_url text,
  file_name text,
  expiry_date date NOT NULL,
  issue_date date,
  notes text DEFAULT '',
  status text DEFAULT 'valid',
  uploaded_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Create staff profiles table
CREATE TABLE IF NOT EXISTS staff_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text DEFAULT 'staff' CHECK (role IN ('admin', 'staff')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE staff_profiles ENABLE ROW LEVEL SECURITY;

-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public)
VALUES ('documents', 'documents', false)
ON CONFLICT (id) DO NOTHING;

-- RLS Policies for clients table
CREATE POLICY "Authenticated staff can view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can insert clients"
  ON clients FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can update clients"
  ON clients FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can delete clients"
  ON clients FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

-- RLS Policies for documents table
CREATE POLICY "Authenticated staff can view all documents"
  ON documents FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can insert documents"
  ON documents FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can update documents"
  ON documents FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can delete documents"
  ON documents FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

-- RLS Policies for staff_profiles table
CREATE POLICY "Staff can view their own profile"
  ON staff_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all staff profiles"
  ON staff_profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.role = 'admin'
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Admins can insert staff profiles"
  ON staff_profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.role = 'admin'
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Admins can update staff profiles"
  ON staff_profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.role = 'admin'
      AND staff_profiles.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.role = 'admin'
      AND staff_profiles.is_active = true
    )
  );

-- Storage policies for documents bucket
CREATE POLICY "Authenticated staff can upload documents"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can view documents"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

CREATE POLICY "Authenticated staff can delete documents"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM staff_profiles
      WHERE staff_profiles.id = auth.uid()
      AND staff_profiles.is_active = true
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_documents_client_id ON documents(client_id);
CREATE INDEX IF NOT EXISTS idx_documents_expiry_date ON documents(expiry_date);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_uploaded_by ON documents(uploaded_by);

-- Create function to automatically update status based on expiry date
CREATE OR REPLACE FUNCTION update_document_status()
RETURNS trigger AS $$
BEGIN
  IF NEW.expiry_date < CURRENT_DATE THEN
    NEW.status = 'expired';
  ELSIF NEW.expiry_date <= CURRENT_DATE + INTERVAL '30 days' THEN
    NEW.status = 'expiring_soon';
  ELSE
    NEW.status = 'valid';
  END IF;
  
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update status on insert/update
DROP TRIGGER IF EXISTS trigger_update_document_status ON documents;
CREATE TRIGGER trigger_update_document_status
  BEFORE INSERT OR UPDATE OF expiry_date ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_document_status();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
DROP TRIGGER IF EXISTS update_clients_updated_at ON clients;
CREATE TRIGGER update_clients_updated_at
  BEFORE UPDATE ON clients
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_documents_updated_at ON documents;
CREATE TRIGGER update_documents_updated_at
  BEFORE UPDATE ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();