/*
  # Fix Security Issues - Remove Unused Indexes and Consolidate Policies

  1. Remove Unused Indexes
    - Drop 6 unused indexes that were flagged by security audit
    - Keep only actively used indexes (primary keys and expiry_date)
    
  2. Consolidate Duplicate RLS Policies
    - Remove duplicate permissive policies on staff_profiles
    - Keep only the broader "authenticated users" policies
    - Simpler policy structure = better performance and maintainability
    
  3. Security Impact
    - Reduces index overhead on write operations
    - Simplifies RLS evaluation for better performance
    - Maintains same security level with cleaner policy structure
*/

-- =============================================
-- STEP 1: Remove Unused Indexes
-- =============================================

-- Documents table unused indexes
DROP INDEX IF EXISTS idx_documents_client_id;
DROP INDEX IF EXISTS idx_documents_uploaded_by;
DROP INDEX IF EXISTS idx_documents_notification_date;
DROP INDEX IF EXISTS idx_documents_status_expiry;

-- Staff profiles table unused indexes
DROP INDEX IF EXISTS idx_staff_profiles_active;
DROP INDEX IF EXISTS idx_staff_profiles_role;

-- =============================================
-- STEP 2: Consolidate Duplicate RLS Policies
-- =============================================

-- Remove the more restrictive "own profile" policies since we have broader policies
DROP POLICY IF EXISTS "Users can view their own profile" ON staff_profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON staff_profiles;

-- Keep the broader policies that already cover these cases:
-- - "Authenticated users can view all staff" (SELECT)
-- - "Authenticated users can update staff profiles" (UPDATE)
-- These provide the necessary access while being simpler to maintain

-- =============================================
-- VERIFICATION
-- =============================================
-- After this migration:
-- - Only essential indexes remain (primary keys + expiry_date for sorting)
-- - No duplicate permissive policies
-- - Same functionality with better performance
-- =============================================