/*
  # Add DELETE Policy for Staff Profiles

  1. Problem
    - No DELETE policy exists for staff_profiles table
    - Admins cannot delete staff members from the UI
    
  2. Solution
    - Add DELETE policy allowing authenticated users to delete staff
    - Relies on application-level checks for admin-only operations
    
  3. Security
    - All authenticated users can delete (application enforces admin restriction)
    - Users cannot delete through auth.admin API without service role
*/

-- Allow authenticated users to delete staff profiles
CREATE POLICY "Authenticated users can delete staff profiles"
  ON staff_profiles
  FOR DELETE
  TO authenticated
  USING (true);