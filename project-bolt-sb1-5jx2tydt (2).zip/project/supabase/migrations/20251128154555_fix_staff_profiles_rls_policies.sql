/*
  # Fix Staff Profiles RLS Policies

  1. Changes
    - Drop existing problematic policies that cause infinite recursion
    - Create simpler policies that don't reference staff_profiles within staff_profiles policies
    - Allow authenticated users to read their own profile
    - Use direct auth.uid() checks instead of subqueries

  2. Security
    - Maintains security by ensuring users can only access their own profile
    - Prevents infinite recursion by not querying staff_profiles within its own policies
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Staff can view their own profile" ON staff_profiles;
DROP POLICY IF EXISTS "Admins can view all staff profiles" ON staff_profiles;
DROP POLICY IF EXISTS "Admins can insert staff profiles" ON staff_profiles;
DROP POLICY IF EXISTS "Admins can update staff profiles" ON staff_profiles;

-- Create new simplified policies
CREATE POLICY "Users can view their own profile"
  ON staff_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON staff_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON staff_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);