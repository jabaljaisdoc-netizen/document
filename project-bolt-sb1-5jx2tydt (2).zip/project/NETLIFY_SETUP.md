# Quick Netlify Setup Guide

## Fix for "Something went wrong while creating your site on Netlify" Error

This error typically occurs when environment variables are missing. Follow these steps:

### Step 1: Set Environment Variables FIRST

**BEFORE deploying**, go to Netlify and set these variables:

1. In Netlify dashboard, go to **Site settings** (or create new site first)
2. Click **Environment variables** in the left sidebar
3. Click **Add a variable**
4. Add these TWO variables:

```
Variable 1:
Key: VITE_SUPABASE_URL
Value: [Your Supabase Project URL]

Variable 2:
Key: VITE_SUPABASE_ANON_KEY
Value: [Your Supabase Anon Key]
```

**Where to find these values:**
- Go to your Supabase dashboard
- Click **Settings** → **API**
- Copy **Project URL** → paste as `VITE_SUPABASE_URL`
- Copy **anon public** key → paste as `VITE_SUPABASE_ANON_KEY`

### Step 2: Deploy Your Site

After setting environment variables:

**Option A: From Git Repository**
1. Push code to GitHub/GitLab/Bitbucket
2. In Netlify, click **Add new site** → **Import an existing project**
3. Connect your repository
4. Netlify will auto-detect build settings
5. Click **Deploy site**

**Option B: Manual Deploy**
1. Run `npm run build` locally
2. Drag the `dist` folder to Netlify
3. Site will deploy immediately

### Step 3: Verify

1. Wait for build to complete
2. Click on your site URL
3. You should see the login page
4. Try logging in

## Common Issues & Solutions

### ❌ "Missing Supabase environment variables"
**Solution**: Go back to Step 1 and double-check variable names are EXACTLY:
- `VITE_SUPABASE_URL` (not SUPABASE_URL)
- `VITE_SUPABASE_ANON_KEY` (not SUPABASE_KEY)

After adding/fixing variables, trigger a new deploy.

### ❌ Build succeeds but app is blank
**Solutions**:
1. Open browser console (F12)
2. Check for CORS errors
3. Verify Supabase URL/Key are correct in Netlify settings
4. Make sure you've run all database migrations in Supabase

### ❌ 404 error when refreshing pages
**Solution**: Already fixed! The `_redirects` file handles this.

### ❌ Build fails with "command not found"
**Solution**: The `netlify.toml` file sets Node version to 18. If it still fails:
1. Go to **Site settings** → **Build & deploy** → **Environment**
2. Add: `NODE_VERSION = "18"`

## Build Configuration Files

Your project now includes:

1. **`netlify.toml`** - Build configuration and redirect rules
2. **`public/_redirects`** - SPA routing fallback
3. **`.gitignore`** - Ensures `.env` is not committed

## Need Help?

1. Check build logs in Netlify dashboard
2. Review `DEPLOYMENT.md` for detailed instructions
3. Verify all Supabase migrations have been applied
4. Ensure RLS policies are active in Supabase

## Important Notes

- ✅ Environment variables must be set in Netlify (not in code)
- ✅ Never commit `.env` file to Git
- ✅ Use `VITE_` prefix for all client-side environment variables
- ✅ Redeploy after changing environment variables
