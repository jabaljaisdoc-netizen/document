# Supabase Database Verification Guide

## Database Overview

The JDC Global Document Expiry Management System uses the following database structure:

### Tables

1. **staff_profiles** - User authentication and roles
2. **clients** - Client information
3. **documents** - Document tracking with expiry dates
4. **settings** - System configuration (admin email for notifications)

## Verification Queries

Run these SQL queries in your Supabase SQL Editor to verify everything is working:

### 1. Check All Tables Exist

```sql
SELECT tablename,
       (SELECT COUNT(*) FROM pg_policies WHERE tablename = t.tablename) as policy_count
FROM pg_tables t
WHERE schemaname = 'public'
ORDER BY tablename;
```

**Expected Result:** 4 tables with their policy counts:
- clients (4 policies)
- documents (4 policies)
- settings (2 policies)
- staff_profiles (6 policies)

### 2. Verify Staff Profiles

```sql
SELECT id, full_name, role, is_active, created_at
FROM staff_profiles
ORDER BY created_at DESC;
```

**Expected Result:** List of all staff members with their roles (admin/staff) and active status.

### 3. Check Documents with Client Information

```sql
SELECT
  d.id,
  d.client_name,
  d.doc_type,
  d.document_name,
  d.expiry_date,
  d.status,
  d.notification_date,
  d.email_sent,
  s.full_name as uploaded_by_name
FROM documents d
LEFT JOIN staff_profiles s ON d.uploaded_by = s.id
ORDER BY d.expiry_date ASC
LIMIT 10;
```

**Expected Result:** Documents with expiry tracking, notification dates, and uploader information.

### 4. Verify Settings Table

```sql
SELECT * FROM settings WHERE id = 'global';
```

**Expected Result:** One row with admin_email configuration.

### 5. Check Row Level Security Policies

```sql
SELECT
  schemaname,
  tablename,
  policyname,
  cmd,
  roles
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, cmd, policyname;
```

**Expected Result:** All RLS policies for secure data access.

### 6. Test Document Status Distribution

```sql
SELECT
  status,
  COUNT(*) as count
FROM documents
GROUP BY status
ORDER BY status;
```

**Expected Result:** Count of documents by status (valid, expiring_soon, expired).

## Email Notification System

The email notification system works as follows:

1. **Notification Date Check:** Documents with a `notification_date` in the past trigger notifications
2. **Status Check:** Only documents with `email_sent = false` send notifications
3. **Admin Email:** Retrieved from the `settings` table (`admin_email` field)
4. **Toast Display:** Currently shows toast messages in the UI (simulated emails)
5. **Email Sent Flag:** After notification, `email_sent` is set to `true` to prevent duplicates

### To Test Notifications:

```sql
-- Create a test document with notification in the past
INSERT INTO documents (
  client_name,
  doc_type,
  document_name,
  document_number,
  expiry_date,
  notification_date,
  status,
  uploaded_by,
  notes
) VALUES (
  'Test Client',
  'Test Document',
  'Test Doc',
  'TEST-001',
  (CURRENT_DATE + INTERVAL '15 days'),
  (CURRENT_DATE - INTERVAL '1 day'),
  'expiring_soon',
  (SELECT id FROM staff_profiles LIMIT 1),
  'Test notification document'
);
```

**Expected Behavior:** When you load the dashboard, you should see a toast notification showing the simulated email.

## Common Issues and Solutions

### Issue: Can't see staff in Staff Management modal
**Solution:** Already fixed! Admins can now view all staff profiles.

### Issue: Can't delete staff members
**Solution:** Already fixed! DELETE policy added for staff_profiles table.

### Issue: White blank page
**Solution:** Environment variables now have fallback values in the code.

### Issue: Email notifications not appearing
**Check:**
1. Document has `notification_date` set
2. `notification_date` is in the past
3. `email_sent` is `false`
4. Document status is 'expiring_soon' or 'expired'

## Environment Variables

The application uses these Supabase environment variables:

```
VITE_SUPABASE_URL=https://cadysragerkgidfivcld.supabase.co
VITE_SUPABASE_ANON_KEY=[Your Anon Key]
```

These are now hardcoded as fallbacks in `src/lib/supabase.ts` to prevent white page issues.

## Security Features

✅ Row Level Security (RLS) enabled on all tables
✅ Authenticated users can view all staff (needed for UI features)
✅ Authenticated users can manage documents
✅ Application enforces admin-only UI restrictions
✅ All policies check authentication status
✅ No public access without authentication

## JDC Global Branding

The application now features JDC Global branding:
- Logo displayed in sidebar with "Powered by JDC Global"
- Logo on login page
- Custom JDC color palette (dark blue #0A2540)
- All blue accent colors replaced with JDC brand colors
